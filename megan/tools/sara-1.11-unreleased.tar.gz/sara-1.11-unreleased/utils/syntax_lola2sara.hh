/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     COMMA = 258,
     COLON = 259,
     SEMICOLON = 260,
     NUMBER = 261,
     NAME = 262,
     FORMULA = 263,
     EQSIGN = 264,
     NEQSIGN = 265,
     GESIGN = 266,
     LESIGN = 267,
     EOL = 268,
     POPEN = 269,
     PCLOSE = 270,
     BOPEN = 271,
     BCLOSE = 272,
     BROPEN = 273,
     BRCLOSE = 274,
     NOTSIGN = 275,
     ANDSIGN = 276,
     ORSIGN = 277,
     IMPLYSIGN = 278,
     EQUIVSIGN = 279,
     XORSIGN = 280,
     TRUESIGN = 281,
     FALSESIGN = 282,
     PLUS = 283,
     MINUS = 284
   };
#endif
/* Tokens.  */
#define COMMA 258
#define COLON 259
#define SEMICOLON 260
#define NUMBER 261
#define NAME 262
#define FORMULA 263
#define EQSIGN 264
#define NEQSIGN 265
#define GESIGN 266
#define LESIGN 267
#define EOL 268
#define POPEN 269
#define PCLOSE 270
#define BOPEN 271
#define BCLOSE 272
#define BROPEN 273
#define BRCLOSE 274
#define NOTSIGN 275
#define ANDSIGN 276
#define ORSIGN 277
#define IMPLYSIGN 278
#define EQUIVSIGN 279
#define XORSIGN 280
#define TRUESIGN 281
#define FALSESIGN 282
#define PLUS 283
#define MINUS 284




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 58 "syntax_lola2sara.yy"
{
  unsigned int val;
}
/* Line 1529 of yacc.c.  */
#line 111 "syntax_lola2sara.hh"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE lola2sara_lval;

