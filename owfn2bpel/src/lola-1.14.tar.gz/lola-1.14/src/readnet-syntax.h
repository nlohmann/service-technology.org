
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     key_final = 258,
     key_automaton = 259,
     key_safe = 260,
     key_next = 261,
     key_analyse = 262,
     key_place = 263,
     key_marking = 264,
     key_transition = 265,
     key_consume = 266,
     key_produce = 267,
     comma = 268,
     colon = 269,
     semicolon = 270,
     ident = 271,
     number = 272,
     eqqual = 273,
     tand = 274,
     tor = 275,
     exists = 276,
     forall = 277,
     globally = 278,
     future = 279,
     until = 280,
     tnot = 281,
     tgeq = 282,
     tgt = 283,
     tleq = 284,
     tlt = 285,
     tneq = 286,
     key_formula = 287,
     lpar = 288,
     rpar = 289,
     key_state = 290,
     key_path = 291,
     key_generator = 292,
     key_record = 293,
     key_end = 294,
     key_sort = 295,
     key_function = 296,
     key_do = 297,
     key_array = 298,
     key_enumerate = 299,
     key_constant = 300,
     key_boolean = 301,
     key_of = 302,
     key_begin = 303,
     key_while = 304,
     key_if = 305,
     key_then = 306,
     key_else = 307,
     key_switch = 308,
     key_case = 309,
     key_repeat = 310,
     key_for = 311,
     key_to = 312,
     key_all = 313,
     key_exit = 314,
     key_return = 315,
     key_true = 316,
     key_false = 317,
     key_mod = 318,
     key_var = 319,
     key_guard = 320,
     tiff = 321,
     timplies = 322,
     lbrack = 323,
     rbrack = 324,
     dot = 325,
     pplus = 326,
     mminus = 327,
     times = 328,
     divide = 329,
     slash = 330,
     key_exists = 331,
     key_strong = 332,
     key_weak = 333,
     key_fair = 334
   };
#endif
/* Tokens.  */
#define key_final 258
#define key_automaton 259
#define key_safe 260
#define key_next 261
#define key_analyse 262
#define key_place 263
#define key_marking 264
#define key_transition 265
#define key_consume 266
#define key_produce 267
#define comma 268
#define colon 269
#define semicolon 270
#define ident 271
#define number 272
#define eqqual 273
#define tand 274
#define tor 275
#define exists 276
#define forall 277
#define globally 278
#define future 279
#define until 280
#define tnot 281
#define tgeq 282
#define tgt 283
#define tleq 284
#define tlt 285
#define tneq 286
#define key_formula 287
#define lpar 288
#define rpar 289
#define key_state 290
#define key_path 291
#define key_generator 292
#define key_record 293
#define key_end 294
#define key_sort 295
#define key_function 296
#define key_do 297
#define key_array 298
#define key_enumerate 299
#define key_constant 300
#define key_boolean 301
#define key_of 302
#define key_begin 303
#define key_while 304
#define key_if 305
#define key_then 306
#define key_else 307
#define key_switch 308
#define key_case 309
#define key_repeat 310
#define key_for 311
#define key_to 312
#define key_all 313
#define key_exit 314
#define key_return 315
#define key_true 316
#define key_false 317
#define key_mod 318
#define key_var 319
#define key_guard 320
#define tiff 321
#define timplies 322
#define lbrack 323
#define rbrack 324
#define dot 325
#define pplus 326
#define mminus 327
#define times 328
#define divide 329
#define slash 330
#define key_exists 331
#define key_strong 332
#define key_weak 333
#define key_fair 334




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 72 "readnet-syntax.yy"

	char * str;
	int value;
	UType * t;
	URcList * rcl;
	UEnList * el;
	ULVal * lval;
	int * exl;
	UStatement * stm;
	case_list * cl;
	UFunction * fu;
	UExpression * ex;
	arc_list * al;
	formula * form;
	IdList * idl;
	UTermList * tlist;
	Place * pl;
	Transition * tr;
	fmode * fm;
	TrSymbol * ts;
	VaSymbol * varsy;



/* Line 1676 of yacc.c  */
#line 235 "readnet-syntax.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;


