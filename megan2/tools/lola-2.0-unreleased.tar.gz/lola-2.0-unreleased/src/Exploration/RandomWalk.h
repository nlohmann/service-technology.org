/*!
\file RandomWalk.h
\author Karsten
\status new

The routines in this file are made for testing fire and checkEnabled.
They can later on be used as a starting point for the "findpath" feature
*/

#pragma once


void randomWalk(NetState &, int = 0);
