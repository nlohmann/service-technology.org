
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Copy the first part of user declarations.  */

/* Line 189 of yacc.c  */
#line 22 "readnet-syntax.yy"

#include "dimensions.H"
#include "net.H"
#include "graph.H"
#include "symboltab.H"
#include "formula.H"
#include "buchi.H"
#include "unfold.H"
#include <cstdio>
#include <limits.h>

extern UBooType * TheBooType;
extern UNumType * TheNumType;
extern char *yytext;

#define YYDEBUG 1
void yyerror(char const *);

class arc_list
{
 public:
	PlSymbol * place;
	UTermList * mt;
	unsigned int nu;
    arc_list    * next;
};   

class case_list
{
	public:
	UStatement * stm;
	UExpression * exp;
	case_list * next;
};

/* list of places and multiplicities to become arcs */

int CurrentCapacity;
UFunction * CurrentFunction;
Place *P;
Transition *T;
Symbol * S;
PlSymbol * PS;
TrSymbol * TS;
SymbolTab * GlobalTable;
SymbolTab * LocalTable;
UVar * V;
VaSymbol * VS;


/* Line 189 of yacc.c  */
#line 124 "readnet-syntax.cc"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 1
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 1
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     key_final = 258,
     key_automaton = 259,
     key_safe = 260,
     key_next = 261,
     key_analyse = 262,
     key_place = 263,
     key_marking = 264,
     key_transition = 265,
     key_consume = 266,
     key_produce = 267,
     comma = 268,
     colon = 269,
     semicolon = 270,
     ident = 271,
     number = 272,
     eqqual = 273,
     tand = 274,
     tor = 275,
     exists = 276,
     forall = 277,
     globally = 278,
     future = 279,
     until = 280,
     tnot = 281,
     tgeq = 282,
     tgt = 283,
     tleq = 284,
     tlt = 285,
     tneq = 286,
     key_formula = 287,
     lpar = 288,
     rpar = 289,
     key_state = 290,
     key_path = 291,
     key_generator = 292,
     key_record = 293,
     key_end = 294,
     key_sort = 295,
     key_function = 296,
     key_do = 297,
     key_array = 298,
     key_enumerate = 299,
     key_constant = 300,
     key_boolean = 301,
     key_of = 302,
     key_begin = 303,
     key_while = 304,
     key_if = 305,
     key_then = 306,
     key_else = 307,
     key_switch = 308,
     key_case = 309,
     key_repeat = 310,
     key_for = 311,
     key_to = 312,
     key_all = 313,
     key_exit = 314,
     key_return = 315,
     key_true = 316,
     key_false = 317,
     key_mod = 318,
     key_var = 319,
     key_guard = 320,
     tiff = 321,
     timplies = 322,
     lbrack = 323,
     rbrack = 324,
     dot = 325,
     pplus = 326,
     mminus = 327,
     times = 328,
     divide = 329,
     slash = 330,
     key_exists = 331,
     key_strong = 332,
     key_weak = 333,
     key_fair = 334
   };
#endif
/* Tokens.  */
#define key_final 258
#define key_automaton 259
#define key_safe 260
#define key_next 261
#define key_analyse 262
#define key_place 263
#define key_marking 264
#define key_transition 265
#define key_consume 266
#define key_produce 267
#define comma 268
#define colon 269
#define semicolon 270
#define ident 271
#define number 272
#define eqqual 273
#define tand 274
#define tor 275
#define exists 276
#define forall 277
#define globally 278
#define future 279
#define until 280
#define tnot 281
#define tgeq 282
#define tgt 283
#define tleq 284
#define tlt 285
#define tneq 286
#define key_formula 287
#define lpar 288
#define rpar 289
#define key_state 290
#define key_path 291
#define key_generator 292
#define key_record 293
#define key_end 294
#define key_sort 295
#define key_function 296
#define key_do 297
#define key_array 298
#define key_enumerate 299
#define key_constant 300
#define key_boolean 301
#define key_of 302
#define key_begin 303
#define key_while 304
#define key_if 305
#define key_then 306
#define key_else 307
#define key_switch 308
#define key_case 309
#define key_repeat 310
#define key_for 311
#define key_to 312
#define key_all 313
#define key_exit 314
#define key_return 315
#define key_true 316
#define key_false 317
#define key_mod 318
#define key_var 319
#define key_guard 320
#define tiff 321
#define timplies 322
#define lbrack 323
#define rbrack 324
#define dot 325
#define pplus 326
#define mminus 327
#define times 328
#define divide 329
#define slash 330
#define key_exists 331
#define key_strong 332
#define key_weak 333
#define key_fair 334




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 72 "readnet-syntax.yy"

	char * str;
	int value;
	UType * t;
	URcList * rcl;
	UEnList * el;
	ULVal * lval;
	int * exl;
	UStatement * stm;
	case_list * cl;
	UFunction * fu;
	UExpression * ex;
	arc_list * al;
	formula * form;
	IdList * idl;
	UTermList * tlist;
	Place * pl;
	Transition * tr;
	fmode * fm;
	TrSymbol * ts;
	VaSymbol * varsy;



/* Line 214 of yacc.c  */
#line 343 "readnet-syntax.cc"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */

/* Line 264 of yacc.c  */
#line 172 "readnet-syntax.yy"

extern YYSTYPE yylval;

//// 1 LINE REMOVED BY NIELS //// #include"lex.yy.c"
//// 3 LINES ADDED BY NIELS
extern int yylex();
extern FILE *yyin;
extern int yylineno;
 

/* Line 264 of yacc.c  */
#line 366 "readnet-syntax.cc"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   460

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  80
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  92
/* YYNRULES -- Number of rules.  */
#define YYNRULES  215
/* YYNRULES -- Number of states.  */
#define YYNSTATES  442

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   334

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,    11,    17,    23,    29,    34,    36,
      38,    43,    46,    50,    56,    58,    62,    63,    66,    69,
      70,    74,    76,    79,    84,    86,    88,    92,    97,   103,
     107,   109,   112,   114,   116,   119,   124,   128,   129,   132,
     133,   136,   141,   143,   147,   154,   155,   157,   161,   165,
     169,   171,   175,   177,   179,   181,   183,   185,   187,   189,
     191,   193,   199,   205,   215,   222,   228,   236,   239,   241,
     246,   253,   254,   257,   262,   266,   268,   273,   277,   281,
     285,   287,   291,   295,   297,   300,   302,   306,   310,   314,
     318,   322,   326,   328,   332,   336,   338,   342,   346,   350,
     352,   355,   357,   359,   363,   368,   372,   374,   376,   378,
     380,   382,   387,   388,   390,   394,   398,   400,   404,   406,
     410,   414,   418,   419,   428,   431,   436,   437,   440,   444,
     448,   450,   452,   456,   458,   460,   461,   463,   467,   471,
     475,   477,   481,   483,   487,   489,   494,   495,   497,   501,
     503,   506,   517,   519,   523,   527,   529,   531,   532,   535,
     536,   538,   542,   546,   550,   552,   556,   560,   564,   568,
     572,   576,   580,   584,   588,   591,   595,   600,   605,   609,
     617,   625,   630,   635,   640,   645,   650,   655,   657,   663,
     667,   668,   670,   675,   680,   684,   688,   691,   695,   697,
     703,   705,   707,   711,   715,   716,   721,   725,   729,   731,
     735,   739,   741,   742,   745,   746
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      81,     0,    -1,    87,   134,    -1,    87,   134,    82,   155,
      -1,    87,   134,     7,     8,    86,    -1,    87,   134,     7,
      10,    83,    -1,    87,   134,     7,     9,   132,    -1,    87,
     134,     4,   163,    -1,    32,    -1,   140,    -1,    84,    68,
      85,    69,    -1,   140,    70,    -1,   140,    18,   120,    -1,
      85,    75,   140,    18,   120,    -1,   140,    -1,   140,    70,
     120,    -1,    -1,    87,    88,    -1,    40,    90,    -1,    -1,
      41,    89,    97,    -1,    91,    -1,    90,    91,    -1,    16,
      18,    92,    15,    -1,    46,    -1,    16,    -1,    38,    95,
      39,    -1,    43,    92,    47,    92,    -1,    68,    17,    13,
      17,    69,    -1,    44,    93,    39,    -1,    94,    -1,    94,
      93,    -1,    16,    -1,    96,    -1,    95,    96,    -1,    16,
      14,    92,    15,    -1,   102,    98,   105,    -1,    -1,    64,
      99,    -1,    -1,    99,   100,    -1,   101,    14,    92,    15,
      -1,    16,    -1,    16,    13,   101,    -1,    16,    33,   103,
      34,    14,    92,    -1,    -1,   104,    -1,   103,    15,   104,
      -1,   101,    14,    92,    -1,    48,   106,    39,    -1,   107,
      -1,   106,    15,   107,    -1,   108,    -1,   109,    -1,   110,
      -1,   111,    -1,   112,    -1,   115,    -1,   118,    -1,   113,
      -1,   114,    -1,    49,   120,    42,   106,    39,    -1,    55,
     106,    25,   120,    39,    -1,    56,    16,    18,   120,    57,
     120,    42,   106,    39,    -1,    56,    58,    16,    42,   106,
      39,    -1,    50,   120,    51,   106,    39,    -1,    50,   120,
      51,   106,    52,   106,    39,    -1,    60,   120,    -1,    59,
      -1,    53,   120,   116,    39,    -1,    53,   120,   116,    52,
     106,    39,    -1,    -1,   117,   116,    -1,    54,   120,    14,
     106,    -1,   119,    18,   120,    -1,    16,    -1,   119,    68,
     120,    69,    -1,   119,    70,    16,    -1,   120,    66,   121,
      -1,   120,    67,   121,    -1,   121,    -1,   121,    19,   122,
      -1,   121,    20,   122,    -1,   122,    -1,    26,   122,    -1,
     123,    -1,   123,    18,   124,    -1,   123,    28,   124,    -1,
     123,    30,   124,    -1,   123,    27,   124,    -1,   123,    29,
     124,    -1,   123,    31,   124,    -1,   124,    -1,   124,    71,
     125,    -1,   124,    72,   125,    -1,   125,    -1,   125,    73,
     126,    -1,   125,    74,   126,    -1,   125,    63,   126,    -1,
     126,    -1,    72,   127,    -1,   127,    -1,    16,    -1,   119,
      70,    16,    -1,   119,    68,   120,    69,    -1,    33,   120,
      34,    -1,    61,    -1,    62,    -1,   128,    -1,   130,    -1,
      17,    -1,    16,    33,   129,    34,    -1,    -1,   120,    -1,
     120,    13,   129,    -1,    68,   131,    69,    -1,   120,    -1,
     120,    75,   131,    -1,   133,    -1,   132,    13,   133,    -1,
     140,    14,    17,    -1,   140,    14,   143,    -1,    -1,     8,
     136,    15,     9,   135,   141,    15,   147,    -1,   137,   138,
      -1,   136,    15,   137,   138,    -1,    -1,     5,    14,    -1,
       5,    17,    14,    -1,   138,    13,   139,    -1,   139,    -1,
     140,    -1,   140,    14,    92,    -1,    16,    -1,    17,    -1,
      -1,   142,    -1,   141,    13,   142,    -1,   140,    14,    17,
      -1,   140,    14,   143,    -1,   144,    -1,   143,    71,   144,
      -1,   145,    -1,   145,    14,    17,    -1,    16,    -1,    16,
      33,   146,    34,    -1,    -1,   145,    -1,   145,    13,   146,
      -1,   148,    -1,   147,   148,    -1,    10,   150,   149,   151,
      11,   152,    15,    12,   152,    15,    -1,    98,    -1,    78,
      79,    98,    -1,    77,    79,    98,    -1,    16,    -1,    17,
      -1,    -1,    65,   120,    -1,    -1,   153,    -1,   153,    13,
     152,    -1,   140,    14,    17,    -1,   140,    14,   143,    -1,
      17,    -1,    33,   120,    34,    -1,   156,    18,   154,    -1,
     156,    31,   154,    -1,   156,    29,   154,    -1,   156,    27,
     154,    -1,   156,    30,   154,    -1,   156,    28,   154,    -1,
     155,    19,   155,    -1,   155,    20,   155,    -1,    26,   155,
      -1,    68,   120,    69,    -1,    76,   157,    14,   155,    -1,
      58,   157,    14,   155,    -1,    33,   155,    34,    -1,    21,
     158,    68,   155,    25,   155,    69,    -1,    22,   158,    68,
     155,    25,   155,    69,    -1,    21,   158,    23,   155,    -1,
      22,   158,    23,   155,    -1,    21,   158,     6,   155,    -1,
      22,   158,     6,   155,    -1,    21,   158,    24,   155,    -1,
      22,   158,    24,   155,    -1,   140,    -1,   140,    70,    33,
     120,    34,    -1,   140,    14,    92,    -1,    -1,   159,    -1,
      76,   157,    14,   159,    -1,    58,   157,    14,   159,    -1,
     159,    19,   159,    -1,   159,    20,   159,    -1,    26,   159,
      -1,    33,   159,    34,    -1,   160,    -1,   160,    70,    68,
     161,    69,    -1,   140,    -1,   162,    -1,   161,    75,   162,
      -1,   140,    18,   120,    -1,    -1,   164,   165,   167,   169,
      -1,    35,   166,    15,    -1,   166,    13,    16,    -1,    16,
      -1,     3,   168,    15,    -1,   168,    13,    16,    -1,    16,
      -1,    -1,   169,   170,    -1,    -1,    10,    16,    57,    16,
      65,   171,   155,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   183,   183,   186,   189,   204,   213,   214,   216,   218,
     228,   286,   297,   309,   331,   337,   362,   363,   365,   366,
     366,   368,   369,   371,   383,   384,   392,   396,   404,   414,
     418,   419,   424,   436,   437,   443,   457,   463,   463,   464,
     464,   465,   480,   485,   492,   522,   522,   522,   523,   539,
     541,   542,   550,   551,   552,   553,   554,   555,   556,   557,
     558,   560,   570,   580,   599,   608,   618,   629,   639,   644,
     666,   689,   690,   692,   698,   708,   716,   731,   752,   764,
     776,   778,   790,   802,   804,   815,   817,   825,   833,   841,
     849,   857,   865,   867,   879,   891,   893,   905,   917,   929,
     931,   942,   944,   982,  1008,  1029,  1030,  1034,  1038,  1039,
    1040,  1044,  1069,  1070,  1075,  1081,  1110,  1115,  1121,  1122,
    1124,  1143,  1185,  1185,  1320,  1321,  1323,  1324,  1325,  1327,
    1328,  1330,  1341,  1376,  1377,  1379,  1380,  1381,  1383,  1402,
    1444,  1445,  1447,  1448,  1451,  1472,  1503,  1504,  1505,  1511,
    1512,  1514,  1748,  1749,  1750,  1752,  1753,  1755,  1756,  1758,
    1759,  1760,  1765,  1783,  1808,  1813,  1821,  1826,  1831,  1836,
    1841,  1846,  1851,  1854,  1857,  1860,  1867,  1871,  1875,  1878,
    1881,  1884,  1887,  1890,  1893,  1896,  1899,  1903,  1909,  1920,
    1928,  1929,  1931,  1935,  1939,  1942,  1945,  1948,  1949,  1956,
    1964,  1970,  1971,  1976,  1989,  1989,  2040,  2050,  2066,  2083,
    2085,  2090,  2096,  2097,  2099,  2099
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "key_final", "key_automaton", "key_safe",
  "key_next", "key_analyse", "key_place", "key_marking", "key_transition",
  "key_consume", "key_produce", "comma", "colon", "semicolon", "ident",
  "number", "eqqual", "tand", "tor", "exists", "forall", "globally",
  "future", "until", "tnot", "tgeq", "tgt", "tleq", "tlt", "tneq",
  "key_formula", "lpar", "rpar", "key_state", "key_path", "key_generator",
  "key_record", "key_end", "key_sort", "key_function", "key_do",
  "key_array", "key_enumerate", "key_constant", "key_boolean", "key_of",
  "key_begin", "key_while", "key_if", "key_then", "key_else", "key_switch",
  "key_case", "key_repeat", "key_for", "key_to", "key_all", "key_exit",
  "key_return", "key_true", "key_false", "key_mod", "key_var", "key_guard",
  "tiff", "timplies", "lbrack", "rbrack", "dot", "pplus", "mminus",
  "times", "divide", "slash", "key_exists", "key_strong", "key_weak",
  "key_fair", "$accept", "input", "formulaheader", "atransition",
  "hlprefix", "firingmode", "aplace", "declarations", "declaration", "$@1",
  "sortdeclarations", "sortdeclaration", "sortdescription", "enums", "enu",
  "recordcomponents", "recordcomponent", "functiondeclaration",
  "vardeclarations", "vdeclarations", "vdeclaration", "identlist", "head",
  "fparlists", "fparlist", "body", "statement_seq", "statement",
  "while_statement", "repeat_statement", "for_statement",
  "forall_statement", "if_statement", "return_statement", "exit_statement",
  "case_statement", "caselist", "case", "assignment", "lvalue",
  "expression", "express", "expre", "expr", "exp", "term", "factor", "fac",
  "functioncall", "expressionlist", "arrayvalue", "valuelist",
  "amarkinglist", "amarking", "net", "$@2", "placelists", "capacity",
  "placelist", "place", "nodeident", "markinglist", "marking", "multiterm",
  "mtcomponent", "hlterm", "termlist", "transitionlist", "transition",
  "transitionvariables", "tname", "guard", "arclist", "arc", "numex",
  "ctlformula", "cplace", "quantification", "transformula",
  "transitionformula", "formulatransition", "parfiringmode", "fmodeblock",
  "automaton", "$@3", "statepart", "statelist", "finalpart", "finallist",
  "transitionpart", "btransition", "$@4", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    80,    81,    81,    81,    81,    81,    81,    82,    83,
      83,    84,    85,    85,    86,    86,    87,    87,    88,    89,
      88,    90,    90,    91,    92,    92,    92,    92,    92,    92,
      93,    93,    94,    95,    95,    96,    97,    98,    98,    99,
      99,   100,   101,   101,   102,   103,   103,   103,   104,   105,
     106,   106,   107,   107,   107,   107,   107,   107,   107,   107,
     107,   108,   109,   110,   111,   112,   112,   113,   114,   115,
     115,   116,   116,   117,   118,   119,   119,   119,   120,   120,
     120,   121,   121,   121,   122,   122,   123,   123,   123,   123,
     123,   123,   123,   124,   124,   124,   125,   125,   125,   125,
     126,   126,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   128,   129,   129,   129,   130,   131,   131,   132,   132,
     133,   133,   135,   134,   136,   136,   137,   137,   137,   138,
     138,   139,   139,   140,   140,   141,   141,   141,   142,   142,
     143,   143,   144,   144,   145,   145,   146,   146,   146,   147,
     147,   148,   149,   149,   149,   150,   150,   151,   151,   152,
     152,   152,   153,   153,   154,   154,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   156,   156,   157,
     158,   158,   159,   159,   159,   159,   159,   159,   159,   159,
     160,   161,   161,   162,   164,   163,   165,   166,   166,   167,
     168,   168,   169,   169,   171,   170
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     4,     5,     5,     5,     4,     1,     1,
       4,     2,     3,     5,     1,     3,     0,     2,     2,     0,
       3,     1,     2,     4,     1,     1,     3,     4,     5,     3,
       1,     2,     1,     1,     2,     4,     3,     0,     2,     0,
       2,     4,     1,     3,     6,     0,     1,     3,     3,     3,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     5,     5,     9,     6,     5,     7,     2,     1,     4,
       6,     0,     2,     4,     3,     1,     4,     3,     3,     3,
       1,     3,     3,     1,     2,     1,     3,     3,     3,     3,
       3,     3,     1,     3,     3,     1,     3,     3,     3,     1,
       2,     1,     1,     3,     4,     3,     1,     1,     1,     1,
       1,     4,     0,     1,     3,     3,     1,     3,     1,     3,
       3,     3,     0,     8,     2,     4,     0,     2,     3,     3,
       1,     1,     3,     1,     1,     0,     1,     3,     3,     3,
       1,     3,     1,     3,     1,     4,     0,     1,     3,     1,
       2,    10,     1,     3,     3,     1,     1,     0,     2,     0,
       1,     3,     3,     3,     1,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     2,     3,     4,     4,     3,     7,
       7,     4,     4,     4,     4,     4,     4,     1,     5,     3,
       0,     1,     4,     4,     3,     3,     2,     3,     1,     5,
       1,     1,     3,     3,     0,     4,     3,     3,     1,     3,
       3,     1,     0,     2,     0,     7
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
      16,     0,     0,     1,   126,     0,    19,    17,     2,     0,
       0,     0,     0,    18,    21,     0,   204,     0,     8,     0,
     127,     0,   126,   133,   134,   124,   130,   131,     0,    22,
       0,    20,    37,     7,     0,     0,     0,     0,   190,   190,
       0,     0,     0,     0,     0,   187,     3,     0,   128,   122,
       0,     0,     0,    25,     0,     0,     0,    24,     0,     0,
      45,    39,     0,     0,     0,     4,    14,     6,   118,     0,
       5,     0,     9,     0,     0,     0,     0,   200,     0,   191,
     198,     0,   174,     0,     0,     0,   102,   110,     0,     0,
     106,   107,     0,     0,     0,     0,    80,    83,    85,    92,
      95,    99,   101,   108,   109,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   135,   125,   129,   132,     0,
       0,    33,     0,    32,     0,    30,     0,    23,    42,     0,
       0,    46,    38,     0,    36,   208,     0,     0,   212,     0,
       0,     0,     0,    11,   196,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   178,
       0,     0,   112,    84,     0,   116,     0,   100,     0,     0,
       0,     0,   175,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   172,   173,
     164,     0,   166,   169,   171,   168,   170,   167,     0,     0,
     136,     0,    26,    34,     0,    29,    31,     0,     0,     0,
       0,     0,    40,     0,    75,     0,     0,     0,     0,     0,
      68,     0,     0,    50,    52,    53,    54,    55,    56,    59,
      60,    57,    58,     0,     0,   206,   211,     0,   205,    15,
     119,   144,   120,   121,   140,   142,     0,     0,   197,     0,
       0,   183,   181,   185,     0,   194,   195,     0,   184,   182,
     186,     0,   189,   177,   113,     0,   105,     0,   115,     0,
     103,    78,    79,    81,    82,    86,    89,    87,    90,    88,
      91,    93,    94,    98,    96,    97,   176,     0,     0,     0,
       0,     0,     0,    27,     0,    43,    48,    47,     0,     0,
       0,     0,    71,     0,     0,     0,    67,     0,    49,     0,
       0,     0,   207,     0,   209,     0,   213,   146,     0,     0,
      10,     0,     0,   193,   192,     0,     0,     0,   201,     0,
     112,   111,   117,   104,   188,   165,   138,   139,   137,     0,
     123,   149,    35,    28,    44,     0,     0,     0,     0,     0,
      71,     0,     0,     0,    51,    74,     0,    77,   210,     0,
     147,     0,   141,   143,     0,    12,     0,     0,   199,     0,
       0,   114,   155,   156,    37,   150,    41,     0,     0,     0,
      69,     0,    72,     0,     0,     0,    76,     0,   146,   145,
       0,   179,   203,   202,   180,     0,     0,   152,   157,    61,
      65,     0,     0,     0,    62,     0,     0,     0,   148,    13,
      37,    37,     0,     0,     0,    73,    70,     0,    64,   214,
     154,   153,   158,   159,    66,     0,     0,     0,     0,   160,
       0,   215,     0,     0,   159,    63,   162,   163,   159,   161,
       0,   151
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,    19,    70,    71,   246,    65,     2,     7,    15,
      13,    14,    59,   124,   125,   120,   121,    31,    62,   132,
     212,   129,    32,   130,   131,   134,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   349,   350,   232,    94,
     165,    96,    97,    98,    99,   100,   101,   102,   103,   265,
     104,   166,    67,    68,     8,   115,    10,    11,    25,    26,
      45,   199,   200,   243,   244,   245,   361,   340,   341,   398,
     374,   413,   428,   429,   192,    46,    47,    85,    78,    79,
      80,   327,   328,    33,    34,    64,   136,   138,   237,   238,
     316,   426
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -345
static const yytype_int16 yypact[] =
{
    -345,    20,    67,  -345,    18,    -5,  -345,  -345,    52,   118,
     137,    70,    96,    -5,  -345,   133,  -345,   283,  -345,    25,
    -345,   158,   275,  -345,  -345,   177,  -345,   164,   130,  -345,
     180,  -345,   162,  -345,   202,    70,    70,    70,    44,    44,
      25,    25,    70,   134,    70,   212,   223,   271,  -345,  -345,
      70,    70,   130,  -345,   245,   130,   254,  -345,   270,   282,
     300,  -345,   295,   314,   343,  -345,   287,   356,  -345,   360,
    -345,   302,   305,    44,    44,    70,    70,  -345,    11,   329,
     306,    13,   223,   124,   363,   365,    10,  -345,   134,   134,
    -345,  -345,   134,   168,   -18,   242,   331,  -345,   276,   281,
     159,  -345,  -345,  -345,  -345,   366,   348,    25,    25,   195,
     195,   195,   195,   195,   195,    70,   177,  -345,  -345,   368,
       6,  -345,   336,  -345,   346,   254,   371,  -345,   373,   374,
     106,  -345,   300,   207,  -345,  -345,   237,   375,  -345,   134,
      70,   338,    70,  -345,   329,   200,   376,   378,    25,    25,
      25,    25,    44,    44,   321,    25,    25,    25,    25,  -345,
     130,    25,   134,  -345,    72,   198,   324,  -345,   134,   379,
     134,   134,  -345,   134,   134,   146,   146,   146,   146,   146,
     146,   146,   146,   146,   146,   146,    25,   134,  -345,  -345,
    -345,   134,  -345,  -345,  -345,  -345,  -345,  -345,   380,   325,
    -345,   130,  -345,  -345,   130,  -345,  -345,   381,   300,   130,
     300,   382,  -345,   383,  -345,   134,   134,   134,   207,    -1,
    -345,   134,    84,  -345,  -345,  -345,  -345,  -345,  -345,  -345,
    -345,  -345,  -345,    26,   384,  -345,  -345,   326,   389,   293,
    -345,   369,  -345,   330,  -345,   390,   -37,   385,  -345,    44,
      44,   223,   223,   223,   249,  -345,  -345,    70,   223,   223,
     223,   258,  -345,  -345,     5,   372,  -345,   134,  -345,   246,
     274,   331,   331,  -345,  -345,   281,   281,   281,   281,   281,
     281,   159,   159,  -345,  -345,  -345,  -345,    99,   127,   345,
      70,   395,   392,  -345,   339,  -345,  -345,  -345,   130,   130,
      88,   174,   181,   184,   391,   394,   293,   207,  -345,   134,
     134,   397,  -345,   398,  -345,   399,  -345,   400,   400,   401,
    -345,    70,   134,  -345,  -345,    25,   393,   136,  -345,    25,
     134,  -345,  -345,   277,  -345,  -345,  -345,   330,  -345,   347,
     395,  -345,  -345,  -345,  -345,   402,   207,   207,   134,   -23,
     367,   134,   134,   377,  -345,   293,   265,  -345,  -345,   386,
     407,   388,  -345,  -345,   406,   293,    29,   134,  -345,    70,
      34,  -345,  -345,  -345,   167,  -345,  -345,   165,    61,     7,
    -345,   207,  -345,    58,   192,   207,  -345,   409,   400,  -345,
     134,  -345,   293,  -345,  -345,   350,   351,  -345,   361,  -345,
    -345,   207,   207,   171,  -345,   134,   182,   370,  -345,   293,
     162,   162,   134,   417,   185,   416,  -345,   103,  -345,  -345,
    -345,  -345,   293,    70,  -345,   207,    25,   418,   419,   420,
     188,   223,   349,   424,    70,  -345,  -345,   330,    70,  -345,
     422,  -345
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -345,  -345,  -345,  -345,  -345,  -345,  -345,  -345,  -345,  -345,
    -345,   425,   -45,   315,  -345,  -345,   319,  -345,  -344,  -345,
    -345,  -126,  -345,  -345,   231,  -345,  -210,   135,  -345,  -345,
    -345,  -345,  -345,  -345,  -345,  -345,    94,  -345,  -345,  -130,
     -34,   197,   -84,  -345,   144,   191,   152,   352,  -345,   116,
    -345,   183,  -345,   307,  -345,  -345,  -345,   426,   403,   404,
     -11,  -345,   161,  -284,   131,  -303,    64,  -345,   114,  -345,
    -345,  -345,  -153,  -345,   215,   -39,  -345,    51,   421,   -61,
    -345,  -345,    87,  -345,  -345,  -345,  -345,  -345,  -345,  -345,
    -345,  -345
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -78
static const yytype_int16 yytable[] =
{
      27,    82,    83,   233,   163,   337,   213,   118,   303,    95,
     122,    12,   144,   145,   360,   304,   380,   148,   330,   155,
       3,   402,   119,     9,    66,    69,    72,    77,    77,   381,
     397,    84,   320,    84,   149,   150,   156,   157,   321,    27,
      27,    23,    24,   162,   309,   202,    38,    39,   107,   108,
     168,    40,   169,   107,   108,   164,    16,   305,    41,    17,
      23,    24,    77,    77,    84,    84,   420,   421,   188,   189,
      73,   170,   171,   170,   171,     4,   307,    74,   -75,   151,
     -75,   158,   295,    42,    18,   360,    23,    24,   233,   273,
     274,   255,   256,    43,   310,   105,   311,   404,   391,   307,
     400,    44,    75,   394,   198,   239,   266,     5,     6,   251,
     252,   253,   254,   401,    28,   262,   258,   259,   260,   261,
      76,   210,   263,   308,   170,   171,   146,   147,   264,    69,
     346,   247,    20,   334,   269,    21,   377,   378,   170,   171,
     211,    77,    77,   107,   108,   425,    53,   286,   437,    30,
      86,    87,    22,   287,   170,   171,   292,   288,   159,   293,
      88,   335,    86,    87,   296,   170,   171,    89,    54,   170,
     171,   403,    48,    55,    56,   406,    57,   233,    52,    89,
     307,   300,   301,   302,    86,    87,   307,   306,   323,   324,
      51,   414,   415,   170,   171,    90,    91,   307,    58,   307,
     307,    89,    92,   307,   399,   368,    93,    90,    91,   351,
     416,   369,   190,    60,    92,   430,   233,   233,    93,   152,
     153,   418,   183,   214,   424,   347,    61,   435,   191,    90,
      91,    61,   184,   185,   248,   348,    92,    63,    77,    77,
     170,   171,   107,   108,   395,   396,   326,   170,   171,   405,
     234,   233,   235,   344,   345,   233,   215,   216,   170,   171,
     217,   119,   218,   219,   170,   171,   220,   221,   107,   108,
     123,   233,   233,   267,   325,   355,   356,   107,   108,   198,
       9,   439,   106,   329,    49,   440,   366,   126,   365,   109,
     370,    35,    36,    37,   175,   233,   264,   127,   110,   111,
     112,   113,   114,   176,   177,   178,   179,   180,   170,   171,
     364,   172,   170,   171,   379,   333,   128,   383,   384,   275,
     276,   277,   278,   279,   280,   193,   194,   195,   196,   197,
     135,   170,   171,   392,   386,   283,   284,   285,   290,   313,
     291,   314,   -77,   133,   -77,   -76,   137,   -76,   152,   153,
     173,   174,   181,   182,   241,   242,   409,   139,   326,   170,
     171,   241,   336,   372,   373,   241,   436,   271,   272,   140,
     142,   417,   281,   282,   141,   143,   154,   160,   422,   161,
     186,   187,   201,   204,   207,   205,   208,   431,   209,   257,
     249,   236,   250,   268,   289,   270,   298,   299,   294,   315,
     312,   318,   317,   322,   319,   339,   331,   342,   343,   352,
     353,   367,   427,   357,   358,   359,   241,   376,   363,   385,
     388,   348,   389,   427,   390,   407,   412,   427,   423,   410,
     411,   307,   432,   434,   433,   419,   438,   441,    29,   203,
     206,   297,   354,   387,   382,   167,   371,   240,    50,   362,
     332,   338,   408,   116,   375,   117,   393,     0,     0,     0,
      81
};

static const yytype_int16 yycheck[] =
{
      11,    40,    41,   133,    88,   289,   132,    52,   218,    43,
      55,    16,    73,    74,   317,    16,    39,     6,    13,     6,
       0,    14,    16,     5,    35,    36,    37,    38,    39,    52,
     374,    42,    69,    44,    23,    24,    23,    24,    75,    50,
      51,    16,    17,    33,    18,    39,    21,    22,    19,    20,
      68,    26,    70,    19,    20,    89,     4,    58,    33,     7,
      16,    17,    73,    74,    75,    76,   410,   411,   107,   108,
      26,    66,    67,    66,    67,     8,    15,    33,    68,    68,
      70,    68,   208,    58,    32,   388,    16,    17,   218,   173,
     174,   152,   153,    68,    68,    44,    70,    39,    69,    15,
      39,    76,    58,    69,   115,   139,    34,    40,    41,   148,
     149,   150,   151,    52,    18,   160,   155,   156,   157,   158,
      76,    15,   161,    39,    66,    67,    75,    76,   162,   140,
      42,   142,    14,    34,   168,    17,   346,   347,    66,    67,
      34,   152,   153,    19,    20,    42,    16,   186,   432,    16,
      16,    17,    15,   187,    66,    67,   201,   191,    34,   204,
      26,    34,    16,    17,   209,    66,    67,    33,    38,    66,
      67,   381,    14,    43,    44,   385,    46,   307,    14,    33,
      15,   215,   216,   217,    16,    17,    15,   221,   249,   250,
      13,   401,   402,    66,    67,    61,    62,    15,    68,    15,
      15,    33,    68,    15,    39,    69,    72,    61,    62,    25,
      39,    75,    17,    33,    68,   425,   346,   347,    72,    19,
      20,    39,    63,    16,    39,    51,    64,    39,    33,    61,
      62,    64,    73,    74,    34,    54,    68,    35,   249,   250,
      66,    67,    19,    20,    77,    78,   257,    66,    67,    57,
      13,   381,    15,   298,   299,   385,    49,    50,    66,    67,
      53,    16,    55,    56,    66,    67,    59,    60,    19,    20,
      16,   401,   402,    75,    25,   309,   310,    19,    20,   290,
       5,   434,    70,    25,     9,   438,   325,    17,   322,    18,
     329,     8,     9,    10,    18,   425,   330,    15,    27,    28,
      29,    30,    31,    27,    28,    29,    30,    31,    66,    67,
     321,    69,    66,    67,   348,    69,    16,   351,   352,   175,
     176,   177,   178,   179,   180,   110,   111,   112,   113,   114,
      16,    66,    67,   367,    69,   183,   184,   185,    13,    13,
      15,    15,    68,    48,    70,    68,     3,    70,    19,    20,
      19,    20,    71,    72,    16,    17,   390,    70,   369,    66,
      67,    16,    17,    16,    17,    16,    17,   170,   171,    13,
      68,   405,   181,   182,    14,    70,    70,    14,   412,    14,
      14,    33,    14,    47,    13,    39,    13,   426,    14,    68,
      14,    16,    14,    69,    14,    16,    14,    14,    17,    10,
      16,    71,    33,    18,    14,    10,    34,    15,    69,    18,
      16,    18,   423,    16,    16,    16,    16,    15,    17,    42,
      13,    54,    34,   434,    18,    16,    65,   438,    11,    79,
      79,    15,    14,    13,    15,    65,    12,    15,    13,   120,
     125,   210,   307,    57,   350,    93,   330,   140,    22,   318,
     267,   290,   388,    50,   340,    51,   369,    -1,    -1,    -1,
      39
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    81,    87,     0,     8,    40,    41,    88,   134,     5,
     136,   137,    16,    90,    91,    89,     4,     7,    32,    82,
      14,    17,    15,    16,    17,   138,   139,   140,    18,    91,
      16,    97,   102,   163,   164,     8,     9,    10,    21,    22,
      26,    33,    58,    68,    76,   140,   155,   156,    14,     9,
     137,    13,    14,    16,    38,    43,    44,    46,    68,    92,
      33,    64,    98,    35,   165,    86,   140,   132,   133,   140,
      83,    84,   140,    26,    33,    58,    76,   140,   158,   159,
     160,   158,   155,   155,   140,   157,    16,    17,    26,    33,
      61,    62,    68,    72,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   130,   157,    70,    19,    20,    18,
      27,    28,    29,    30,    31,   135,   138,   139,    92,    16,
      95,    96,    92,    16,    93,    94,    17,    15,    16,   101,
     103,   104,    99,    48,   105,    16,   166,     3,   167,    70,
      13,    14,    68,    70,   159,   159,   157,   157,     6,    23,
      24,    68,    19,    20,    70,     6,    23,    24,    68,    34,
      14,    14,    33,   122,   120,   120,   131,   127,    68,    70,
      66,    67,    69,    19,    20,    18,    27,    28,    29,    30,
      31,    71,    72,    63,    73,    74,    14,    33,   155,   155,
      17,    33,   154,   154,   154,   154,   154,   154,   140,   141,
     142,    14,    39,    96,    47,    39,    93,    13,    13,    14,
      15,    34,   100,   101,    16,    49,    50,    53,    55,    56,
      59,    60,   106,   107,   108,   109,   110,   111,   112,   113,
     114,   115,   118,   119,    13,    15,    16,   168,   169,   120,
     133,    16,    17,   143,   144,   145,    85,   140,    34,    14,
      14,   155,   155,   155,   155,   159,   159,    68,   155,   155,
     155,   155,    92,   155,   120,   129,    34,    75,    69,   120,
      16,   121,   121,   122,   122,   124,   124,   124,   124,   124,
     124,   125,   125,   126,   126,   126,   155,   120,   120,    14,
      13,    15,    92,    92,    17,   101,    92,   104,    14,    14,
     120,   120,   120,   106,    16,    58,   120,    15,    39,    18,
      68,    70,    16,    13,    15,    10,   170,    33,    71,    14,
      69,    75,    18,   159,   159,    25,   140,   161,   162,    25,
      13,    34,   131,    69,    34,    34,    17,   143,   142,    10,
     147,   148,    15,    69,    92,    92,    42,    51,    54,   116,
     117,    25,    18,    16,   107,   120,   120,    16,    16,    16,
     145,   146,   144,    17,   140,   120,   155,    18,    69,    75,
     155,   129,    16,    17,   150,   148,    15,   106,   106,   120,
      39,    52,   116,   120,   120,    42,    69,    57,    13,    34,
      18,    69,   120,   162,    69,    77,    78,    98,   149,    39,
      39,    52,    14,   106,    39,    57,   106,    16,   146,   120,
      79,    79,    65,   151,   106,   106,    39,   120,    39,    65,
      98,    98,   120,    11,    39,    42,   171,   140,   152,   153,
     106,   155,    14,    15,    13,    39,    17,   143,    12,   152,
     152,    15
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1455 of yacc.c  */
#line 183 "readnet-syntax.yy"
    { 
F = (formula *) 0 ; 
}
    break;

  case 3:

/* Line 1455 of yacc.c  */
#line 186 "readnet-syntax.yy"
    { 
F = (yyvsp[(4) - (4)].form);
}
    break;

  case 4:

/* Line 1455 of yacc.c  */
#line 189 "readnet-syntax.yy"
    {
	F = (formula *) 0;
	CheckPlace = (yyvsp[(5) - (5)].pl);
#ifdef STUBBORN
	Transitions[0]->StartOfStubbornList = (Transition *) 0;
int i;
	for(i=0;CheckPlace -> PreTransitions[i];i++)
	{
		CheckPlace->PreTransitions[i]->instubborn = true;
		CheckPlace->PreTransitions[i]->NextStubborn = Transitions[0]->StartOfStubbornList;
		Transitions[0]->StartOfStubbornList = CheckPlace->PreTransitions[i];
	}
	Transitions[0]->EndOfStubbornList = LastAttractor = CheckPlace -> PreTransitions[0];
#endif
                }
    break;

  case 5:

/* Line 1455 of yacc.c  */
#line 204 "readnet-syntax.yy"
    {
	F = (formula *) 0;
	CheckTransition = (yyvsp[(5) - (5)].tr);
#ifdef STUBBORN
	Transitions[0]->EndOfStubbornList = LastAttractor = Transitions[0]->StartOfStubbornList = CheckTransition;
	CheckTransition -> NextStubborn = (Transition *) 0;
	CheckTransition -> instubborn = true;
#endif
	}
    break;

  case 6:

/* Line 1455 of yacc.c  */
#line 213 "readnet-syntax.yy"
    { F = (formula *) 0;}
    break;

  case 7:

/* Line 1455 of yacc.c  */
#line 214 "readnet-syntax.yy"
    {F = (formula *) 0;}
    break;

  case 8:

/* Line 1455 of yacc.c  */
#line 216 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(2);}
    break;

  case 9:

/* Line 1455 of yacc.c  */
#line 218 "readnet-syntax.yy"
    {
				TS = (TrSymbol *) TransitionTable -> lookup((yyvsp[(1) - (1)].str));
				if(!TS) yyerror("transition does not exist");
				if(TS -> vars && TS -> vars -> card)
				{
					yyerror("HL transition requires firing mode");
				}
				(yyval.tr) = TS -> transition;
			}
    break;

  case 10:

/* Line 1455 of yacc.c  */
#line 228 "readnet-syntax.yy"
    {
		   unsigned int i, j,card;
		   fmode * fm;
		   // unused: VaSymbol * v;
		   UValue * vl;
		   char ** cc;
		   char ** inst;
		   unsigned int len;
		   for(card=0,fm=(yyvsp[(3) - (4)].fm);fm;fm = fm -> next,card++);
		   if(card != (yyvsp[(1) - (4)].ts) -> vars -> card)
		   {
			yyerror("firing mode incomplete");
		   }
		   cc = new char * [ card + 10];
		   inst= new char * [ card + 10];
		   len = strlen((yyvsp[(1) - (4)].ts)->name) + 4;
		   j=0;
		   for(i=0;i<LocalTable->size;i++)
		   {
			for(VS = (VaSymbol *) (LocalTable -> table[i]);VS; VS = (VaSymbol *) (VS -> next))
			{
				UValue * pl;
				for(fm=(yyvsp[(3) - (4)].fm);fm;fm=fm ->next)
				{	
					if(fm -> v == VS) break;
				}
				if(!fm) yyerror("firing mode incomplete");
				vl = fm -> t -> evaluate();
				pl = VS -> var -> type -> make();
				pl -> assign(vl);
				cc[j] = pl -> text();
				inst[j] = new char [strlen(VS -> name)+strlen(cc[j]) + 20];
				strcpy(inst[j],VS -> name);
				strcpy(inst[j]+strlen(inst[j]),"=");
				strcpy(inst[j]+strlen(inst[j]),cc[j]);
				len += strlen(inst[j]) + 1;
				j++;
			}
		   } 
		   char * llt;
		   llt = new char[len+20];
		   strcpy(llt,(yyvsp[(1) - (4)].ts) -> name);
		   strcpy(llt+strlen(llt),".[");
		   for(j=0;j<card;j++)
		   {
			strcpy(llt + strlen(llt),inst[j]);
			strcpy(llt + strlen(llt),"|");
		   }
		   strcpy(llt + (strlen(llt) - 1),"]");
		   TS = (TrSymbol *) TransitionTable -> lookup(llt);
		   if(!TS) yyerror("transition instance does not exist");
		   if(TS -> vars && TS -> vars -> card)
		   {
			yyerror("HL and LL transition names mixed up");
		   }
		   (yyval.tr) = TS -> transition;
		   }
    break;

  case 11:

/* Line 1455 of yacc.c  */
#line 286 "readnet-syntax.yy"
    {
			TS = (TrSymbol *) TransitionTable -> lookup((yyvsp[(1) - (2)].str));
			if(!TS) yyerror("transition does not exist");
			if( ( !(TS -> vars) || TS -> vars -> card == 0))
			{
				yyerror("only HL transitions require firing mode");
			}
			(yyval.ts) = TS;
			LocalTable = TS -> vars;
			}
    break;

  case 12:

/* Line 1455 of yacc.c  */
#line 297 "readnet-syntax.yy"
    {
			VS = (VaSymbol *) LocalTable -> lookup((yyvsp[(1) - (3)].str));
			if(!VS) yyerror("transition does not have this variable");
			if(! (VS -> var -> type -> iscompatible((yyvsp[(3) - (3)].ex) -> type)))
			{
				yyerror("expression not compatible with transition variable");
			}
			(yyval.fm) = new fmode;
			(yyval.fm) -> next = (fmode *) 0;
			(yyval.fm) -> v = VS;
			(yyval.fm) -> t = (yyvsp[(3) - (3)].ex);
			}
    break;

  case 13:

/* Line 1455 of yacc.c  */
#line 309 "readnet-syntax.yy"
    {
			fmode * fm;
			VS = (VaSymbol *) LocalTable -> lookup((yyvsp[(3) - (5)].str));
			if(!VS) yyerror("transition does not have this variable");
			if(! (VS -> var -> type -> iscompatible((yyvsp[(5) - (5)].ex) -> type)))
			{
				yyerror("expression not compatible with transition variable");
			}
			(yyval.fm) = new fmode;
			(yyval.fm) -> next = (yyvsp[(1) - (5)].fm);
			(yyval.fm) -> v = VS;
			(yyval.fm) -> t = (yyvsp[(5) - (5)].ex) ;
			for(fm = (yyvsp[(1) - (5)].fm); fm ; fm = fm -> next)
			{
				if(fm -> v == (yyval.fm) -> v)
				{
					yyerror("variable appears twice in firing mode");
				}
			}
			}
    break;

  case 14:

/* Line 1455 of yacc.c  */
#line 331 "readnet-syntax.yy"
    {
	PS = (PlSymbol *) PlaceTable ->lookup((yyvsp[(1) - (1)].str)); 
	if(!PS) yyerror("Place does not exist");
	if(PS -> sort) yyerror("HL places require instance");
	(yyval.pl) = PS -> place;
	}
    break;

  case 15:

/* Line 1455 of yacc.c  */
#line 337 "readnet-syntax.yy"
    {
	PS = (PlSymbol *) PlaceTable ->lookup((yyvsp[(1) - (3)].str)); 
	if(!PS) yyerror("Place does not exist");
	if(!(PS -> sort)) yyerror("LL places do not require instance");
	if(!(PS -> sort -> iscompatible((yyvsp[(3) - (3)].ex) -> type)))
	{	
		yyerror("place color not compatible to place sort");
	}
	UValue * vl , * pl;
	vl = (yyvsp[(3) - (3)].ex) -> evaluate();
	pl = PS -> sort -> make();
	pl -> assign(vl);
	char * inst;
	inst = pl -> text();
	char * ll;
	ll = new char [strlen(PS -> name) + strlen(inst) + 20];
	strcpy(ll,PS -> name);
	strcpy(ll + strlen(ll),".");
	strcpy(ll + strlen(ll),inst);
	PS = (PlSymbol *) PlaceTable -> lookup(ll);
	if(!PS) yyerror("place instance does not exist");
	if(PS->sort) yyerror("mixed up HL and LL place names");
	(yyval.pl) = PS -> place;
	}
    break;

  case 19:

/* Line 1455 of yacc.c  */
#line 366 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(1);}
    break;

  case 23:

/* Line 1455 of yacc.c  */
#line 371 "readnet-syntax.yy"
    {
				// sort symbols are globally visible. A sort entry in the
				// symbol table relates a name to a sort description (UType)

				SoSymbol * s;
				if( (s = (SoSymbol *) (GlobalTable -> lookup((yyvsp[(1) - (4)].str)))) )
				{
					yyerror("sort symbol name already used");
				}
				s = new SoSymbol((yyvsp[(1) - (4)].str),(yyvsp[(3) - (4)].t));
			}
    break;

  case 24:

/* Line 1455 of yacc.c  */
#line 383 "readnet-syntax.yy"
    { (yyval.t) = TheBooType; }
    break;

  case 25:

/* Line 1455 of yacc.c  */
#line 384 "readnet-syntax.yy"
    {
							// assign an additional name to an existing sort
							SoSymbol * s;
							s = (SoSymbol *) (GlobalTable -> lookup((yyvsp[(1) - (1)].str)));
							if(!s) yyerror("undefined sort name");
							if(s -> kind != so) yyerror("sort name expected");
							(yyval.t) = s -> type;
						}
    break;

  case 26:

/* Line 1455 of yacc.c  */
#line 392 "readnet-syntax.yy"
    {
						// unused: URcList * rl;
						(yyval.t) = new URecType((yyvsp[(2) - (3)].rcl));
						}
    break;

  case 27:

/* Line 1455 of yacc.c  */
#line 396 "readnet-syntax.yy"
    {
						// index type must be scalar
						if((yyvsp[(2) - (4)].t) -> tag != boo && (yyvsp[(2) - (4)].t) ->tag != num && (yyvsp[(2) - (4)].t) -> tag != enu)
						{
							yyerror("non-scalar type as index of array");
						}
						(yyval.t) = new UArrType((yyvsp[(2) - (4)].t),(yyvsp[(4) - (4)].t));
						}
    break;

  case 28:

/* Line 1455 of yacc.c  */
#line 404 "readnet-syntax.yy"
    {
				// integer interval
				unsigned int l,r;
				sscanf((yyvsp[(2) - (5)].str),"%u",&l);
				sscanf((yyvsp[(4) - (5)].str),"%u",&r);
				{
					if(l > r) yyerror("negative range in integer type");
				}
				(yyval.t) = new UNumType(l,r);
			}
    break;

  case 29:

/* Line 1455 of yacc.c  */
#line 414 "readnet-syntax.yy"
    {
					(yyval.t) = new UEnuType((yyvsp[(2) - (3)].el));
					}
    break;

  case 31:

/* Line 1455 of yacc.c  */
#line 419 "readnet-syntax.yy"
    { 
					(yyvsp[(1) - (2)].el) -> next = (yyvsp[(2) - (2)].el);
					(yyval.el) = (yyvsp[(1) - (2)].el);
				 }
    break;

  case 32:

/* Line 1455 of yacc.c  */
#line 424 "readnet-syntax.yy"
    {
			EnSymbol * e;
			UEnList * eel;
			e = (EnSymbol *) GlobalTable -> lookup((yyvsp[(1) - (1)].str));
			if(e) yyerror("element name of enumeration already used");
			e = new EnSymbol((yyvsp[(1) - (1)].str));
			eel = new UEnList;
			eel -> sy = e;
			eel -> next = (UEnList *) 0;
			(yyval.el) = eel;
			}
    break;

  case 34:

/* Line 1455 of yacc.c  */
#line 438 "readnet-syntax.yy"
    {
						(yyvsp[(2) - (2)].rcl) -> next = (yyvsp[(1) - (2)].rcl);
						(yyval.rcl) = (yyvsp[(2) - (2)].rcl);
					}
    break;

  case 35:

/* Line 1455 of yacc.c  */
#line 443 "readnet-syntax.yy"
    {
						RcSymbol * r;
						URcList * rl;
						r = (RcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (4)].str));
						if(r) yyerror("record component name already used");
						r = new RcSymbol((yyvsp[(1) - (4)].str),(yyvsp[(3) - (4)].t));
						rl = new URcList;
						rl -> next = (URcList *) 0;
						rl -> sy = r;
						rl -> ty = (yyvsp[(3) - (4)].t);
						(yyval.rcl) = rl;
					}
    break;

  case 36:

/* Line 1455 of yacc.c  */
#line 458 "readnet-syntax.yy"
    {
							(yyvsp[(1) - (3)].fu) -> body = (yyvsp[(3) - (3)].stm);
							(yyvsp[(1) - (3)].fu) -> localsymb = LocalTable;
						}
    break;

  case 41:

/* Line 1455 of yacc.c  */
#line 465 "readnet-syntax.yy"
    {
							IdList * il;
							for(il = (yyvsp[(1) - (4)].idl);il;il=il->next)
							{	
								VaSymbol * v;
								UVar * vvv;
								if( (v = (VaSymbol *) (LocalTable -> lookup(il -> name))) )
								{
									yyerror("variable name already used");
								}
								vvv = new UVar((yyvsp[(3) - (4)].t));
								v = new VaSymbol(il -> name,vvv);
							}
							}
    break;

  case 42:

/* Line 1455 of yacc.c  */
#line 480 "readnet-syntax.yy"
    {
				(yyval.idl) = new IdList;
				(yyval.idl) -> name = (yyvsp[(1) - (1)].str);
				(yyval.idl) -> next = (IdList *) 0;
				}
    break;

  case 43:

/* Line 1455 of yacc.c  */
#line 485 "readnet-syntax.yy"
    {
				(yyval.idl) = new IdList;
				(yyval.idl) -> name = (yyvsp[(1) - (3)].str);
				(yyval.idl) -> next = (yyvsp[(3) - (3)].idl);
			}
    break;

  case 44:

/* Line 1455 of yacc.c  */
#line 492 "readnet-syntax.yy"
    {
			FcSymbol * fs;
			UFunction * f;
			fs = (FcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (6)].str));
			if(fs)
			{
				yyerror("function name already used");
			}
			CurrentFunction = f = new UFunction();
			fs = new FcSymbol((yyvsp[(1) - (6)].str),f);
			f -> type = (yyvsp[(6) - (6)].t);
			f -> localsymb = LocalTable;
			f -> result = (UValueList *) 0;
			f -> resultstack = (UResultList *) 0;
			f -> arity = LocalTable -> card;
			f -> formalpar = new UVar * [f -> arity +5];
			int i;
			i = 0;
			for(unsigned int j = 0; j < LocalTable -> size; j++)
			{
				Symbol * s;
				for(s = LocalTable -> table[j]; s; s = s -> next)
				{	
					f -> formalpar[(f->arity -1) -i++] = ((VaSymbol *) s) -> var;
				}
			}
				
				(yyval.fu) = f;
		}
    break;

  case 48:

/* Line 1455 of yacc.c  */
#line 523 "readnet-syntax.yy"
    {
		IdList * il;
		for(il = (yyvsp[(1) - (3)].idl); il; il = il -> next)
		{
								VaSymbol * v;
								UVar * vvv;
								if( (v = (VaSymbol *) (LocalTable -> lookup(il -> name))) )
								{
									yyerror("variable name already used");
								}
								vvv = new UVar((yyvsp[(3) - (3)].t));
								v = new VaSymbol(il -> name,vvv);
			
		}
		}
    break;

  case 49:

/* Line 1455 of yacc.c  */
#line 539 "readnet-syntax.yy"
    { (yyval.stm) = (yyvsp[(2) - (3)].stm); }
    break;

  case 51:

/* Line 1455 of yacc.c  */
#line 542 "readnet-syntax.yy"
    { 
										   UStatement * s;
										   s = new USequenceStatement;
                                          ((USequenceStatement * ) s) -> first = (yyvsp[(1) - (3)].stm);
                                          ((USequenceStatement *) s) -> second = (yyvsp[(3) - (3)].stm);
											(yyval.stm) = s;
					}
    break;

  case 61:

/* Line 1455 of yacc.c  */
#line 560 "readnet-syntax.yy"
    {
		if((yyvsp[(2) - (5)].ex) -> type -> tag != boo)
		{
			yyerror("while condition must be boolean");
		}
		(yyval.stm) = new UWhileStatement;
		((UWhileStatement *) (yyval.stm)) -> cond = (yyvsp[(2) - (5)].ex);
		((UWhileStatement *) (yyval.stm)) -> body = (yyvsp[(4) - (5)].stm);
		}
    break;

  case 62:

/* Line 1455 of yacc.c  */
#line 570 "readnet-syntax.yy"
    {
		if((yyvsp[(4) - (5)].ex) -> type -> tag != boo)
		{
			yyerror("while condition must be boolean");
		}
		(yyval.stm) = new URepeatStatement;
		((URepeatStatement *) (yyval.stm)) -> cond = (yyvsp[(4) - (5)].ex);
		((URepeatStatement *) (yyval.stm)) -> body = (yyvsp[(2) - (5)].stm);
		}
    break;

  case 63:

/* Line 1455 of yacc.c  */
#line 580 "readnet-syntax.yy"
    {
		VaSymbol * v;
		v = (VaSymbol *) LocalTable -> lookup((yyvsp[(2) - (9)].str));
		if(!v) yyerror("loop variable not declared");
		(yyval.stm) = new UForStatement;
		((UForStatement *) (yyval.stm)) -> var = v -> var;
		if(! ( v->var->type -> iscompatible((yyvsp[(4) - (9)].ex) -> type)))
		{
			yyerror("initial expression of for statement not compatible to counter variable");
		}
		if(! ( v->var->type -> iscompatible((yyvsp[(6) - (9)].ex) -> type)))
		{
			yyerror("exit expression of for statement not compatible to counter variable");
		}
		((UForStatement *) (yyval.stm)) -> init = (yyvsp[(4) - (9)].ex);
		((UForStatement *) (yyval.stm)) -> finit = (yyvsp[(6) - (9)].ex);
		((UForStatement *) (yyval.stm)) -> body = (yyvsp[(8) - (9)].stm);
		}
    break;

  case 64:

/* Line 1455 of yacc.c  */
#line 599 "readnet-syntax.yy"
    {
			VaSymbol * v;
			v = (VaSymbol *) LocalTable -> lookup((yyvsp[(3) - (6)].str));
			if(!v) yyerror("loop variable not declared");
			(yyval.stm) = new UForallStatement;
			((UForallStatement *) (yyval.stm)) -> var = v -> var;
			((UForallStatement *) (yyval.stm)) -> body = (yyvsp[(5) - (6)].stm);
			}
    break;

  case 65:

/* Line 1455 of yacc.c  */
#line 608 "readnet-syntax.yy"
    {
			if((yyvsp[(2) - (5)].ex) -> type -> tag != boo)
			{
				yyerror("condition in if statement must be boolean");
			}
			(yyval.stm) = new UConditionalStatement;
			((UConditionalStatement *) (yyval.stm)) -> cond = (yyvsp[(2) - (5)].ex);
			((UConditionalStatement *) (yyval.stm)) -> yes = (yyvsp[(4) - (5)].stm);
			((UConditionalStatement *) (yyval.stm)) -> no = new UNopStatement;
			}
    break;

  case 66:

/* Line 1455 of yacc.c  */
#line 618 "readnet-syntax.yy"
    {
			if((yyvsp[(2) - (7)].ex) -> type -> tag != boo)
			{
				yyerror("condition in if statement must be boolean");
			}
			(yyval.stm) = new UConditionalStatement;
			((UConditionalStatement *) (yyval.stm)) -> cond = (yyvsp[(2) - (7)].ex);
			((UConditionalStatement *) (yyval.stm)) -> yes = (yyvsp[(4) - (7)].stm);
			((UConditionalStatement *) (yyval.stm)) -> no = (yyvsp[(6) - (7)].stm);
			}
    break;

  case 67:

/* Line 1455 of yacc.c  */
#line 629 "readnet-syntax.yy"
    {
		   if(!((yyvsp[(2) - (2)].ex) -> type -> iscompatible(CurrentFunction -> type)))
		   {
			yyerror("returned value incompatible to function type");
		   }
		   (yyval.stm) = new UReturnStatement;
		   ((UReturnStatement *) (yyval.stm)) -> fct = CurrentFunction;
		   ((UReturnStatement *) (yyval.stm)) -> exp = (yyvsp[(2) - (2)].ex);
		   }
    break;

  case 68:

/* Line 1455 of yacc.c  */
#line 639 "readnet-syntax.yy"
    {
			(yyval.stm) = new UExitStatement;
			((UExitStatement *) (yyval.stm)) -> fct = CurrentFunction;
			 }
    break;

  case 69:

/* Line 1455 of yacc.c  */
#line 644 "readnet-syntax.yy"
    {
		unsigned int crd;
		case_list * l;
		for(l = (yyvsp[(3) - (4)].cl),crd = 0; l; l = l -> next,crd++)
		{
			if(!((yyvsp[(2) - (4)].ex) -> type -> iscompatible(l -> exp -> type)))
			{
				yyerror("case item incompatible to case expression");
			}
	    	}
		(yyval.stm) = new UCaseStatement;
		((UCaseStatement *) (yyval.stm)) -> exp = (yyvsp[(2) - (4)].ex);
		((UCaseStatement *) (yyval.stm)) -> cond = new UExpression * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> yes = new UStatement * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> def = new UNopStatement;
		for(l=(yyvsp[(3) - (4)].cl),crd=0; l; l = l -> next,crd++)
		{	
			((UCaseStatement *) (yyval.stm)) -> cond[crd] = l -> exp;
			((UCaseStatement *) (yyval.stm)) -> yes[crd] = l -> stm;
		}
		((UCaseStatement *) (yyval.stm)) -> card = crd;
		}
    break;

  case 70:

/* Line 1455 of yacc.c  */
#line 666 "readnet-syntax.yy"
    {
		unsigned int crd;
		case_list * l;
		for(l = (yyvsp[(3) - (6)].cl),crd = 0; l; l = l -> next,crd++)
		{
			if(!((yyvsp[(2) - (6)].ex) -> type -> iscompatible(l -> exp -> type)))
			{
				yyerror("case item incompatible to case expression");
			}
	    	}
		(yyval.stm) = new UCaseStatement;
		((UCaseStatement *) (yyval.stm)) -> exp = (yyvsp[(2) - (6)].ex);
		((UCaseStatement *) (yyval.stm)) -> cond = new UExpression * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> yes = new UStatement * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> def = (yyvsp[(5) - (6)].stm);
		for(l=(yyvsp[(3) - (6)].cl),crd=0; l; l = l -> next,crd++)
		{	
			((UCaseStatement *) (yyval.stm)) -> cond[crd] = l -> exp;
			((UCaseStatement *) (yyval.stm)) -> yes[crd] = l -> stm;
		}
		((UCaseStatement *) (yyval.stm)) -> card = crd;
		}
    break;

  case 71:

/* Line 1455 of yacc.c  */
#line 689 "readnet-syntax.yy"
    { (yyval.cl) = (case_list *) 0;}
    break;

  case 72:

/* Line 1455 of yacc.c  */
#line 690 "readnet-syntax.yy"
    {(yyvsp[(1) - (2)].cl) -> next = (yyvsp[(2) - (2)].cl); (yyval.cl) = (yyvsp[(1) - (2)].cl);}
    break;

  case 73:

/* Line 1455 of yacc.c  */
#line 692 "readnet-syntax.yy"
    { (yyval.cl) = new case_list;
					(yyval.cl) -> exp = (yyvsp[(2) - (4)].ex);
					(yyval.cl) -> stm = (yyvsp[(4) - (4)].stm);
					(yyval.cl) -> next = (case_list *) 0;
					}
    break;

  case 74:

/* Line 1455 of yacc.c  */
#line 698 "readnet-syntax.yy"
    {
		if(!((yyvsp[(1) - (3)].lval) -> type -> iscompatible((yyvsp[(3) - (3)].ex)->type)))
		{	
			yyerror("incompatible types in assignment");
		}	
		(yyval.stm) = new UAssignStatement;
		((UAssignStatement *) (yyval.stm)) -> left = (yyvsp[(1) - (3)].lval);
		((UAssignStatement *) (yyval.stm)) -> right = (yyvsp[(3) - (3)].ex);
		}
    break;

  case 75:

/* Line 1455 of yacc.c  */
#line 708 "readnet-syntax.yy"
    {
		VaSymbol * v;
		v = (VaSymbol *) (LocalTable -> lookup((yyvsp[(1) - (1)].str)));
		if(!v) yyerror("variable not defined");
		(yyval.lval) = new UVarLVal;
		((UVarLVal*) (yyval.lval)) -> var = v -> var;
		(yyval.lval) -> type = ((UVarLVal *) (yyval.lval)) -> var -> type;
		}
    break;

  case 76:

/* Line 1455 of yacc.c  */
#line 716 "readnet-syntax.yy"
    {
		if((yyvsp[(1) - (4)].lval) -> type -> tag != arr)
		{
			yyerror("component of something not an array referenced");
		}
		if(((yyvsp[(3) - (4)].ex) -> type -> tag != boo) && ((yyvsp[(3) - (4)].ex) -> type -> tag != num) && ((yyvsp[(3) - (4)].ex) -> type -> tag != enu))
		{
			yyerror("non-scalar expression for array index");
		}
		(yyval.lval) = new UArrayLVal;
		(yyval.lval) -> type = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> component;
		((UArrayLVal *) (yyval.lval)) -> indextype = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> index;
		((UArrayLVal *) (yyval.lval)) -> parent = (yyvsp[(1) - (4)].lval);
		((UArrayLVal *) (yyval.lval)) -> idx = (yyvsp[(3) - (4)].ex);
		}
    break;

  case 77:

/* Line 1455 of yacc.c  */
#line 731 "readnet-syntax.yy"
    {
			RcSymbol *r;
			r = (RcSymbol *) (GlobalTable -> lookup((yyvsp[(3) - (3)].str)));
			if((!r) || (r -> kind != rc))
			{
				yyerror("record component unknown");
			}
			if((yyvsp[(1) - (3)].lval) -> type -> tag != rec)
			{
				yyerror("component of something not a record referenced");
			}
			if(r -> index >= ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> card ||(r -> type != ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r->index]))
			{
				yyerror("record type does not have such component");
			}
			(yyval.lval) = new URecordLVal;
			(yyval.lval) -> type = ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r -> index];
			((URecordLVal *) (yyval.lval)) -> parent = (yyvsp[(1) - (3)].lval);
			((URecordLVal *) (yyval.lval)) -> offset = r -> index;
		}
    break;

  case 78:

/* Line 1455 of yacc.c  */
#line 752 "readnet-syntax.yy"
    {
				UDivExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new UDivExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 79:

/* Line 1455 of yacc.c  */
#line 764 "readnet-syntax.yy"
    {
				USubExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new USubExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 81:

/* Line 1455 of yacc.c  */
#line 778 "readnet-syntax.yy"
    {
				UMulExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new UMulExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 82:

/* Line 1455 of yacc.c  */
#line 790 "readnet-syntax.yy"
    {
				UAddExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new UAddExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 84:

/* Line 1455 of yacc.c  */
#line 804 "readnet-syntax.yy"
    {
				UNegExpression * e;
				if(!deep_compatible((yyvsp[(2) - (2)].ex) -> type,boo))
				{
					yyerror("boolean operator applied to non-boolean operand");
				}
				e = new UNegExpression;
				e -> left = (yyvsp[(2) - (2)].ex);
				e -> type = (yyvsp[(2) - (2)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 86:

/* Line 1455 of yacc.c  */
#line 817 "readnet-syntax.yy"
    {
				UEqualExpression * e;
				e = new UEqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 87:

/* Line 1455 of yacc.c  */
#line 825 "readnet-syntax.yy"
    {
				UGreaterthanExpression * e;
				e = new UGreaterthanExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 88:

/* Line 1455 of yacc.c  */
#line 833 "readnet-syntax.yy"
    {
				ULessthanExpression * e;
				e = new ULessthanExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 89:

/* Line 1455 of yacc.c  */
#line 841 "readnet-syntax.yy"
    {
				UGreatereqqualExpression * e;
				e = new UGreatereqqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 90:

/* Line 1455 of yacc.c  */
#line 849 "readnet-syntax.yy"
    {
				ULesseqqualExpression * e;
				e = new ULesseqqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 91:

/* Line 1455 of yacc.c  */
#line 857 "readnet-syntax.yy"
    {
				UUneqqualExpression * e;
				e = new UUneqqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 93:

/* Line 1455 of yacc.c  */
#line 867 "readnet-syntax.yy"
    {
				UAddExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UAddExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 94:

/* Line 1455 of yacc.c  */
#line 879 "readnet-syntax.yy"
    {
				USubExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new USubExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 96:

/* Line 1455 of yacc.c  */
#line 893 "readnet-syntax.yy"
    {
				UMulExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UMulExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 97:

/* Line 1455 of yacc.c  */
#line 905 "readnet-syntax.yy"
    {
				UDivExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UDivExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 98:

/* Line 1455 of yacc.c  */
#line 917 "readnet-syntax.yy"
    {
				UModExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UModExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 100:

/* Line 1455 of yacc.c  */
#line 931 "readnet-syntax.yy"
    {
				UNegExpression * e;
				if(!deep_compatible((yyvsp[(2) - (2)].ex) -> type,num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UNegExpression;
				e -> left = (yyvsp[(2) - (2)].ex);
				e -> type = (yyvsp[(2) - (2)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 102:

/* Line 1455 of yacc.c  */
#line 944 "readnet-syntax.yy"
    {
		Symbol * s;
		s = LocalTable -> lookup((yyvsp[(1) - (1)].str));
		if(s)
		{
			// s is local variable

			VaSymbol * v;
			ULvalExpression * e;
			ULVal * l;
			v = (VaSymbol *) s;
			l = new UVarLVal;
			((UVarLVal *) l) -> var = v -> var;
			((UVarLVal *) l) -> type = ((UVarLVal *) l) -> var -> type;
			e = new ULvalExpression;
			e -> type = l -> type;
			e -> lval = l;
			(yyval.ex) = e;
		}
		else
		{
			// try global symbol
			EnSymbol *n;
			UEnuconstantExpression * e;
			s = GlobalTable -> lookup((yyvsp[(1) - (1)].str));
			if(!s) 
			{
				printf("%s", (yyvsp[(1) - (1)].str));
				yyerror("identifier not defined");
			}
			if(s->kind != en) yyerror("identifier of wrong kind");
			n = (EnSymbol *) s;
			e = new UEnuconstantExpression;
			e -> type = n -> type;
			e -> nu = n -> ord;
			(yyval.ex) = e;
		}
		}
    break;

  case 103:

/* Line 1455 of yacc.c  */
#line 982 "readnet-syntax.yy"
    {
			RcSymbol *r;
			URecordLVal * l;
			ULvalExpression * e;
			r = (RcSymbol *) (GlobalTable -> lookup((yyvsp[(3) - (3)].str)));
			if((!r) || (r -> kind != rc))
			{
				yyerror("record component unknown");
			}
			if((yyvsp[(1) - (3)].lval) -> type -> tag != rec)
			{
				yyerror("component of something not a record referenced");
			}
			if(r -> index >= ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> card ||(r -> type != ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r->index]))
			{
				yyerror("record type does not have this component");
			}
			l = new URecordLVal;
			l -> type = ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r -> index];
			l -> parent = (yyvsp[(1) - (3)].lval);
			l -> offset = r -> index;
			e = new ULvalExpression;
			e -> type = l -> type;
			e -> lval = l;
			(yyval.ex) = e;
		}
    break;

  case 104:

/* Line 1455 of yacc.c  */
#line 1008 "readnet-syntax.yy"
    {
		UArrayLVal * a;
		ULvalExpression * e;
		if((yyvsp[(1) - (4)].lval) -> type -> tag != arr)
		{
			yyerror("component of something not an array referenced");
		}
		if(((yyvsp[(3) - (4)].ex) -> type -> tag != boo) && ((yyvsp[(3) - (4)].ex) -> type -> tag != num) && ((yyvsp[(3) - (4)].ex) -> type -> tag != enu))
		{
			yyerror("non-scalar expression for array index");
		}
		a = new UArrayLVal;
		a -> type = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> component;
		a -> parent = (yyvsp[(1) - (4)].lval);
		a -> indextype = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> index;
		a -> idx = (yyvsp[(3) - (4)].ex);
		e = new ULvalExpression;
		e -> type = a -> type;
		e -> lval = a;
		(yyval.ex) =e;
		}
    break;

  case 105:

/* Line 1455 of yacc.c  */
#line 1029 "readnet-syntax.yy"
    {(yyval.ex) = (yyvsp[(2) - (3)].ex);}
    break;

  case 106:

/* Line 1455 of yacc.c  */
#line 1030 "readnet-syntax.yy"
    {
		(yyval.ex) = new UTrueExpression;
		(yyval.ex) -> type = TheBooType;
		}
    break;

  case 107:

/* Line 1455 of yacc.c  */
#line 1034 "readnet-syntax.yy"
    {
		(yyval.ex) = new UFalseExpression;
		(yyval.ex) -> type = TheBooType;
		}
    break;

  case 110:

/* Line 1455 of yacc.c  */
#line 1040 "readnet-syntax.yy"
    {(yyval.ex) = new UIntconstantExpression;
			 sscanf((yyvsp[(1) - (1)].str),"%u",&(((UIntconstantExpression *) (yyval.ex)) -> nu)); 
			 (yyval.ex) -> type = TheNumType;}
    break;

  case 111:

/* Line 1455 of yacc.c  */
#line 1044 "readnet-syntax.yy"
    {
					UCallExpression * e;
					case_list * c;
					FcSymbol * f;
					int i;
					f = (FcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (4)].str));
					if(!f) yyerror("undefined function called");
					e = new UCallExpression;
					e -> fct = f -> function;
					e -> type = f -> function -> type;
					e -> currentpar = new UExpression * [f -> function -> arity + 10];
					for(i = 0,c=(yyvsp[(3) - (4)].cl); i < f->  function -> arity; i++)
					{
						if(!c) yyerror("too few arguments to function");
						e -> currentpar[i] = c -> exp;
						if(!(c -> exp -> type -> iscompatible(f -> function -> formalpar[i]->type)))
						{
							yyerror("type mismatch in call parameter");
						}
						c = c -> next;
					}
					if(c) yyerror("to many arguments to function");
					(yyval.ex) = e;
				}
    break;

  case 112:

/* Line 1455 of yacc.c  */
#line 1069 "readnet-syntax.yy"
    {(yyval.cl) = (case_list *) 0;}
    break;

  case 113:

/* Line 1455 of yacc.c  */
#line 1070 "readnet-syntax.yy"
    {
					(yyval.cl) = new case_list;
					(yyval.cl) -> exp = (yyvsp[(1) - (1)].ex);
					(yyval.cl) -> next = (case_list *) 0;
				}
    break;

  case 114:

/* Line 1455 of yacc.c  */
#line 1075 "readnet-syntax.yy"
    {
					(yyval.cl) = new case_list;
					(yyval.cl) -> exp = (yyvsp[(1) - (3)].ex);
					(yyval.cl) -> next = (yyvsp[(3) - (3)].cl);
				}
    break;

  case 115:

/* Line 1455 of yacc.c  */
#line 1081 "readnet-syntax.yy"
    {
					UNumType * it;
					UArrType * at;
					UType * ct;
					unsigned int h;
					int i;
					case_list * c;
					UArrayExpression * e;

					for(c=(yyvsp[(2) - (3)].cl),h=0;c;c = c -> next,h++);
					it = new UNumType(1,h);
					ct = (yyvsp[(2) - (3)].cl) -> exp -> type;
					at = new UArrType(it,ct);
					e = new UArrayExpression;
					e -> type = at;
					e -> card = h;
					e -> cont = new UExpression * [h+10];
					for(i = 0,c = (yyvsp[(2) - (3)].cl); i < h; i++,c = c -> next)
					{
						e -> cont[i] = c -> exp;
						if(!(ct -> iscompatible(c -> exp -> type)))
						{
							yyerror("incompatible types in array value");
						}

					}
					(yyval.ex) = e;
				}
    break;

  case 116:

/* Line 1455 of yacc.c  */
#line 1110 "readnet-syntax.yy"
    {
				(yyval.cl) = new case_list;
				(yyval.cl) ->exp = (yyvsp[(1) - (1)].ex);
				(yyval.cl) -> next = (case_list *) 0;
			}
    break;

  case 117:

/* Line 1455 of yacc.c  */
#line 1115 "readnet-syntax.yy"
    {
				(yyval.cl) = new case_list;
				(yyval.cl) -> next = (yyvsp[(3) - (3)].cl);
				(yyval.cl) -> exp = (yyvsp[(1) - (3)].ex);
			}
    break;

  case 120:

/* Line 1455 of yacc.c  */
#line 1124 "readnet-syntax.yy"
    {
 unsigned int i;
  PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
  if(!PS)
    {
      yyerror("place does not exist");
    }
  if(PS -> sort)
  {
	// HL place, number nicht erlaubt
	yyerror("markings of high level places must be term expressions");
  }
  else
  {
  // LL place, number ist als Anzahl zu interpretieren
  sscanf((yyvsp[(3) - (3)].str),"%u",&i);
  PS->place->target_marking += i;
  }
 }
    break;

  case 121:

/* Line 1455 of yacc.c  */
#line 1143 "readnet-syntax.yy"
    {
				char * inst, * ll;
				UTermList * tl;
				UValueList * vl, * currentvl;
				UValue * pv;
				PlSymbol * PSI;
				PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
				if(!PS)
				{
					yyerror("place does not exist");
				}
				if(!PS -> sort)
				{	
					yyerror("multiterm expression not allowed for low level places");
				}
				pv = PS -> sort -> make();
				for(tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl -> next) // do for all mt components
				{
					// check type compatibility
					if(!(PS -> sort -> iscompatible(tl -> t -> type)))
					{
						yyerror("marking expression not compatible to sort of place");
					}
					vl = tl -> t -> evaluate();
					for(currentvl = vl; currentvl;currentvl = currentvl -> next)
					{
						pv -> assign(currentvl -> val); // type adjustment
						inst = pv -> text();
						ll = new char [strlen((yyvsp[(1) - (3)].str)) + strlen(inst) + 20];
						strcpy(ll,(yyvsp[(1) - (3)].str));
						strcpy(ll + strlen((yyvsp[(1) - (3)].str)),".");
						strcpy(ll + (strlen((yyvsp[(1) - (3)].str)) + 1), inst);
						PSI = (PlSymbol *) PlaceTable -> lookup(ll); 
						if(!PSI)
						{
							yyerror("place instance does not exist");
						}
						PSI -> place -> target_marking += tl -> mult;
					}
				}
			}
    break;

  case 122:

/* Line 1455 of yacc.c  */
#line 1185 "readnet-syntax.yy"
    {LocalTable = (SymbolTab *) 0;}
    break;

  case 123:

/* Line 1455 of yacc.c  */
#line 1185 "readnet-syntax.yy"
    {
  unsigned int i,h,j;
  Symbol * ss;
  // Create array of places
  Places = new Place * [PlaceTable -> card+10];
  CurrentMarking = new unsigned int [PlaceTable -> card+10];
  i = 0;
  for(h=0;h<PlaceTable -> size;h++)
    {
      for(ss= PlaceTable -> table[h];ss;ss = ss -> next)
	{
	  if(!(((PlSymbol *) ss) -> sort))
	  {
		  Places[i++] = ((PlSymbol *) ss) -> place;
	  }
	}
    }
	PlaceTable->card = i;
#ifdef WITHFORMULA
	for(i=0;i<PlaceTable->card;i++)
	{
		Places[i]->propositions = (formula **) 0;
	}
#endif
  // Create array of transitions 
  Transitions = new Transition * [TransitionTable -> card+10];
  i = 0;
  for(h=0;h<TransitionTable -> size;h++)
    {
      for(ss = TransitionTable -> table[h];ss;ss = ss -> next)
	{
	  if(!(((TrSymbol *) ss) -> vars))
	  {
		  Transitions[i++] = ((TrSymbol *) ss) -> transition;
	  }
	}
    }
	TransitionTable->card = i;
  // Create arc list of places pass 1 (count nr of arcs)
  for(i = 0; i < TransitionTable -> card;i++)
    {
      for(j=0;j < Transitions[i]->NrOfArriving;j++)
	{
	  Transitions[i]->ArrivingArcs[j]->pl->NrOfLeaving++;
	}
      for(j=0;j < Transitions[i]->NrOfLeaving;j++)
	{
	  Transitions[i]->LeavingArcs[j]->pl->NrOfArriving++;
	}
    }
  // pass 2 (allocate arc arrays)
  for(i=0;i<PlaceTable -> card;i++)
    {
      Places[i]->ArrivingArcs = new Arc * [Places[i]->NrOfArriving+10];
      Places[i]->NrOfArriving = 0;
      Places[i]->LeavingArcs = new Arc * [Places[i]->NrOfLeaving+10];
      Places[i]->NrOfLeaving = 0;
    }
  // pass 3 (fill in arcs)
  for(i=0;i<TransitionTable -> card;i++)
    {
      for(j=0;j < Transitions[i]->NrOfLeaving;j++)
	{
	  Place * pl;
	  pl = Transitions[i]->LeavingArcs[j]->pl;
	  pl->ArrivingArcs[pl->NrOfArriving] = Transitions[i]->LeavingArcs[j];
	  pl->NrOfArriving ++;
	}
      for(j=0;j < Transitions[i]->NrOfArriving;j++)
	{
	  Place * pl;
	  pl = Transitions[i]->ArrivingArcs[j]->pl;
	  pl->LeavingArcs[pl->NrOfLeaving] = Transitions[i]->ArrivingArcs[j];
	  pl->NrOfLeaving ++;
	}
    }
    for(i=0;i<TransitionTable->card;i++)
    {
#ifdef STUBBORN
      Transitions[i] -> mustbeincluded = Transitions[i]->conflicting;
#if defined(EXTENDED) && defined(MODELCHECKING)
	Transitions[i]->lstfired = new unsigned int [10];
	Transitions[i]->lstdisabled = new unsigned int [10];
#endif
#endif
    }
#if defined(EXTENDED) && defined(MODELCHECKING)
	formulaindex = 0;
	currentdfsnum = 0;
#endif
  // initialize places
#ifdef STUBBORN
  for(i= 0;i < PlaceTable -> card;i++) Places[i]->initialize();
#endif
  Transitions[0]-> StartOfEnabledList = Transitions[0];
// The following pieces of code initialize static attractor sets for
// various problems.
#ifdef BOUNDEDNET
#ifdef STUBBORN
	// initialize list of pumping transitions
	LastAttractor = (Transition*)0;
	int p,c,a; // produced, consumed tokens, current arc
	for(i=0;i< TransitionTable -> card;i++)
	{
		// count produced tokens
		for(a=0,p=0;a<Transitions[i]->NrOfLeaving;a++)
		{
			p += Transitions[i]->LeavingArcs[a] -> Multiplicity;
		}
		// count consumed tokens
		for(a=0,c=0;a<Transitions[i]->NrOfArriving;a++)
		{
			c += Transitions[i]->ArrivingArcs[a]->Multiplicity;
		}
		if(p > c)
		{
			Transitions[i]->instubborn = true;
			if(LastAttractor)
			{
				Transitions[i]->NextStubborn = 
					Transitions[i]->StartOfStubbornList;
				Transitions[i]->StartOfStubbornList = Transitions[i];
			}
			else
			{
				Transitions[i]->StartOfStubbornList = LastAttractor = Transitions[i];
				Transitions[i]-> NextStubborn = (Transition *) 0;
			}
		}
	}
		
#endif
#endif
}
    break;

  case 126:

/* Line 1455 of yacc.c  */
#line 1323 "readnet-syntax.yy"
    { CurrentCapacity = CAPACITY;}
    break;

  case 127:

/* Line 1455 of yacc.c  */
#line 1324 "readnet-syntax.yy"
    {CurrentCapacity = 1;}
    break;

  case 128:

/* Line 1455 of yacc.c  */
#line 1325 "readnet-syntax.yy"
    { sscanf((yyvsp[(2) - (3)].str),"%d",&CurrentCapacity);}
    break;

  case 131:

/* Line 1455 of yacc.c  */
#line 1330 "readnet-syntax.yy"
    {
			 if(PlaceTable -> lookup((yyvsp[(1) - (1)].str)))
			 {
			   yyerror("Place name used twice");
		     }
			 P = new Place((yyvsp[(1) - (1)].str));
		     PS = new PlSymbol(P);
			 PS -> sort = (UType *) 0;
			 P -> capacity = CurrentCapacity;
			 P -> nrbits = CurrentCapacity > 0 ? logzwo(CurrentCapacity) : 32;
		}
    break;

  case 132:

/* Line 1455 of yacc.c  */
#line 1341 "readnet-syntax.yy"
    {
			// high level place: unfold to all instances
			char * c;
			if(PlaceTable -> lookup((yyvsp[(1) - (3)].str)))
			{
				yyerror("Place name used twice");
			}
			c = new char [strlen((yyvsp[(1) - (3)].str))+10];
			strcpy(c,(yyvsp[(1) - (3)].str));
			PS =  new PlSymbol(c);
			PS -> sort = (yyvsp[(3) - (3)].t);
			UValue * v;
			v = (yyvsp[(3) - (3)].t) -> make();
			do
			{
				char * lowlevelplace;
				char * lowtag;
				lowtag = v -> text();
				lowlevelplace = new char [ strlen(c) + strlen(lowtag) + 20];
				strcpy(lowlevelplace,c);
				strcpy(lowlevelplace + strlen(c), ".");
				strcpy(lowlevelplace + strlen(c) + 1, lowtag);
				if(PlaceTable -> lookup(lowlevelplace))
				{
					yyerror("Place instance name already used");
				}
				P = new Place(lowlevelplace);
				P -> capacity = CurrentCapacity;
				P -> nrbits = CurrentCapacity > 0 ? logzwo(CurrentCapacity) : 32;
				PS = new PlSymbol(P);
				PS -> sort = (UType *) 0;
				(*v)++;
			} while(!(v -> isfirst()));
			}
    break;

  case 133:

/* Line 1455 of yacc.c  */
#line 1376 "readnet-syntax.yy"
    { (yyval.str) = (yyvsp[(1) - (1)].str);}
    break;

  case 134:

/* Line 1455 of yacc.c  */
#line 1377 "readnet-syntax.yy"
    {(yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 138:

/* Line 1455 of yacc.c  */
#line 1383 "readnet-syntax.yy"
    {
  unsigned int i;
  PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
  if(!PS)
    {
      yyerror("place does not exist");
    }
  if(PS -> sort)
  {
	// HL place, number nicht erlaubt
	yyerror("markings of high level places must be term expressions");
  }
  else
  {
  // LL place, number ist als Anzahl zu interpretieren
  sscanf((yyvsp[(3) - (3)].str),"%u",&i);
  *(PS->place) += i;
  }
 }
    break;

  case 139:

/* Line 1455 of yacc.c  */
#line 1402 "readnet-syntax.yy"
    {
				char * inst, * ll;
				UTermList * tl;
				UValueList * vl, * currentvl;
				UValue * pv;
				PlSymbol * PSI;
				PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
				if(!PS)
				{
					yyerror("place does not exist");
				}
				if(!PS -> sort)
				{	
					yyerror("multiterm expression not allowed for low level places");
				}
				pv = PS -> sort -> make();
				for(tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl -> next) // do for all mt components
				{
					// check type compatibility
					if(!(PS -> sort -> iscompatible(tl -> t -> type)))
					{
						yyerror("marking expression not compatible to sort of place");
					}
					vl = tl -> t -> evaluate();
					for(currentvl = vl; currentvl;currentvl = currentvl -> next)
					{
						pv -> assign(currentvl -> val); // type adjustment
						inst = pv -> text();
						ll = new char [strlen((yyvsp[(1) - (3)].str)) + strlen(inst) + 20];
						strcpy(ll,(yyvsp[(1) - (3)].str));
						strcpy(ll + strlen((yyvsp[(1) - (3)].str)),".");
						strcpy(ll + (strlen((yyvsp[(1) - (3)].str)) + 1), inst);
						PSI = (PlSymbol *) PlaceTable -> lookup(ll); 
						if(!PSI)
						{
							yyerror("place instance does not exist");
						}
						(* PSI -> place) += tl -> mult;
					}
				}
			}
    break;

  case 140:

/* Line 1455 of yacc.c  */
#line 1444 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist);}
    break;

  case 141:

/* Line 1455 of yacc.c  */
#line 1445 "readnet-syntax.yy"
    {(yyvsp[(3) - (3)].tlist) -> next = (yyvsp[(1) - (3)].tlist); (yyval.tlist) = (yyvsp[(3) - (3)].tlist);}
    break;

  case 142:

/* Line 1455 of yacc.c  */
#line 1447 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist);}
    break;

  case 143:

/* Line 1455 of yacc.c  */
#line 1448 "readnet-syntax.yy"
    { unsigned int i; sscanf((yyvsp[(3) - (3)].str),"%u",&i);(yyvsp[(1) - (3)].tlist) -> mult = i;
								 (yyval.tlist) = (yyvsp[(1) - (3)].tlist);}
    break;

  case 144:

/* Line 1455 of yacc.c  */
#line 1451 "readnet-syntax.yy"
    {
		UTermList * tl;
		UVarTerm * vt;
		if(!LocalTable)
		{
			yyerror("only constant terms are allowed in this context");
		}
		VS =(VaSymbol *)  (LocalTable -> lookup((yyvsp[(1) - (1)].str)));
		if(!VS)
		{
			yyerror("undeclared variable in term");
		}
		tl = new UTermList;
		tl -> next = (UTermList *) 0;
		tl -> mult = 1;
		vt = new UVarTerm;
		tl -> t = vt;
		vt -> v = VS -> var;
		vt -> type = VS -> var -> type;
		(yyval.tlist) =tl;
		}
    break;

  case 145:

/* Line 1455 of yacc.c  */
#line 1472 "readnet-syntax.yy"
    {
		FcSymbol * FS;
		UTermList * tl;
		UOpTerm * ot;
		FS = (FcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (4)].str));
		if(!FS) yyerror("operation symbol not declared");
		if(FS ->kind != fc) yyerror("wrong symbol used as operation symbol");
		unsigned int i;
		UTermList * l;
		for(i=0,l=(yyvsp[(3) - (4)].tlist);l;i++,l=l->next);
		if(i != FS -> function -> arity) yyerror("wrong number of arguments");
		tl = new UTermList;
		tl -> next = (UTermList *) 0;
		tl -> mult = 1;
		ot = new UOpTerm;
		tl -> t = ot;
		ot -> arity = i;
		ot -> f = FS -> function;
		ot -> sub = new UTerm * [i+5];
		for(i=0,l=(yyvsp[(3) - (4)].tlist);i<ot -> arity;i++,l= l -> next)
		{
			if(!(ot -> f -> formalpar[i] -> type -> iscompatible(l -> t -> type)))
			{
				yyerror("type mismatch in subterm(s)");
			}
			ot -> sub[i] = l -> t;
		}
		ot -> type = ot -> f -> type;
		(yyval.tlist) = tl;
	   }
    break;

  case 146:

/* Line 1455 of yacc.c  */
#line 1503 "readnet-syntax.yy"
    {(yyval.tlist) = (UTermList *) 0;}
    break;

  case 147:

/* Line 1455 of yacc.c  */
#line 1504 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist);}
    break;

  case 148:

/* Line 1455 of yacc.c  */
#line 1505 "readnet-syntax.yy"
    {
			(yyvsp[(1) - (3)].tlist) -> next = (yyvsp[(3) - (3)].tlist);
			(yyval.tlist) = (yyvsp[(1) - (3)].tlist);
			}
    break;

  case 151:

/* Line 1455 of yacc.c  */
#line 1514 "readnet-syntax.yy"
    {
  unsigned int card;
  unsigned int i;
  arc_list * current;
  /* 1. Transition anlegen */
  if(TransitionTable -> lookup((yyvsp[(2) - (10)].str)))
    {
      yyerror("transition name used twice");
    }
  TS = new TrSymbol((yyvsp[(2) - (10)].str));
  TS -> vars = LocalTable;
  TS -> guard = (yyvsp[(4) - (10)].ex);

  // unfold HL transitions
  // -> create transition instance for every assignment to the variables that
  //    matches the guard


  // init: initially, all variables have initial value

  while(1)
  {
	if(TS -> guard)
	{
		UValue * v;
		v = TS -> guard -> evaluate();
		if(((UBooValue * )v) -> v == false) goto nextass;
	}
	// A) create LL transition with current variable assignment

  /* generate name */
  char * llt;
  if((!LocalTable) || LocalTable -> card == 0)
  {
	llt = TS -> name;
	TS -> vars = (SymbolTab *) 0;
  }
  else
  {
  char ** assignment;
  unsigned int len;
  len = 0;
  assignment = new char * [LocalTable -> card + 1000];
  VaSymbol * vs;
  unsigned int i,j;
  j=0;
  for(i=0;i < LocalTable -> size; i++)
  {
	for(vs = (VaSymbol *) (LocalTable-> table[i]); vs ; vs = (VaSymbol *) vs -> next)
	{
		char * inst;
		inst = vs -> var -> value -> text();
		assignment[j] = new char[strlen(vs -> name) + 10 + strlen(inst)];
		strcpy(assignment[j],vs -> name);
		strcpy(assignment[j]+strlen(vs -> name),"=");
		strcpy(assignment[j]+strlen(vs -> name)+1,inst);
		len += strlen(assignment[j++]);
	}
  }
  llt = new char [ strlen(TS -> name)  + len + LocalTable -> card + 1000];
  strcpy(llt,TS->name);
  strcpy(llt + strlen(llt),".[");
  for(i=0;i<LocalTable -> card; i++)
  {
	strcpy(llt + strlen(llt),assignment[i]);
	strcpy(llt + strlen(llt),"|");
  }
  strcpy(llt + (strlen(llt) - 1), "]");
  }
  TrSymbol * TSI;
  if((!LocalTable) || LocalTable -> card == 0)
  {
	TSI = TS;
  }
  else
  {
  TSI = (TrSymbol *) TransitionTable -> lookup(llt);
  if(TSI) yyerror("transition instance already exists");
  TSI = new TrSymbol(llt);
  TSI -> vars = (SymbolTab *) 0;
  TSI -> guard = (UExpression *) 0;
  }
  T = TSI -> transition = new Transition(TSI -> name);
  T -> fairness = (yyvsp[(3) - (10)].value);
  /* 2. Inliste eintragen */
  /* HL-Boegen in LL-Boegen uebersetzen und zur Liste hinzufuegen */
  arc_list * root;
  root = (yyvsp[(6) - (10)].al);
  for(current = root;current; current = current -> next)
  {
	if(current -> mt)
	{
		// traverse multiterm
		arc_list * a;
		UTermList * mc;
		UValueList * vl;
		UValueList * vc;
		UValue * pv;
		pv = current -> place -> sort -> make();
		for(mc = current -> mt; mc ; mc = mc -> next)
		{	
			vl = mc -> t -> evaluate();

			for(vc = vl; vc; vc  = vc -> next)
			{
				char * inst;
				char * ll;
				pv -> assign(vc -> val);
				inst = pv -> text();
				ll = new char [strlen(current -> place -> name) + strlen(inst) + 20];
				strcpy(ll,current->place->name);
				strcpy(ll+strlen(current->place->name),".");
				strcpy(ll+strlen(current->place->name)+1,inst);
				PS = (PlSymbol *) PlaceTable -> lookup(ll);
				if(!ll) yyerror("place instance does not exist");
				if(PS -> sort) yyerror("arcs to HL places are not allowed");
				a = new arc_list;
				a -> place = PS;
				a -> mt = (UTermList *) 0;
				a -> nu =mc -> mult;
				a -> next = root;
				root = a;
			}
		}
	}
  }
  /* Anzahl der Boegen */
  for(card = 0, current = root;current;card++,current = current -> next);
  T->ArrivingArcs = new  Arc * [card+10];
  /* Schleife ueber alle Boegen */
  for(current = root;current;current = current -> next)
    {
	  /* Bogen ist nur HL-Bogen */
	  if(current -> place -> sort) continue;
      /* gibt es Bogen schon? */

      for(i = 0; i < T->NrOfArriving;i++)
	{
	  if(current->place -> place == T->ArrivingArcs[i]->pl)
	    {
	      /* Bogen existiert, nur Vielfachheit addieren */
	      *(T->ArrivingArcs[i]) += current->nu;
	      break;
	    }
	}
      if(i>=T->NrOfArriving)
	{
	  T->ArrivingArcs[T->NrOfArriving] = new Arc(T,current->place->place,true,current->nu);
	  T->NrOfArriving++;
	  current -> place -> place -> references ++;
	}
    }
  /* 2. Outliste eintragen */
  root = (yyvsp[(9) - (10)].al);
  for(current = root;current; current = current -> next)
  {
	if(current -> mt)
	{
		// traverse multiterm
		arc_list * a;
		UTermList * mc;
		UValueList * vl;
		UValueList * vc;
		UValue * pv;
		pv = current -> place -> sort -> make();
		for(mc = current -> mt; mc ; mc = mc -> next)
		{	
			vl = mc -> t -> evaluate();
			for(vc = vl; vc; vc  = vc -> next)
			{
				char * inst;
				char * ll;
				pv -> assign(vc -> val);
				inst = pv -> text();
				ll = new char [strlen(current -> place -> name) + strlen(inst) + 20];
				strcpy(ll,current->place->name);
				strcpy(ll+strlen(current->place->name),".");
				strcpy(ll+strlen(current->place->name)+1,inst);
				PS = (PlSymbol *) PlaceTable -> lookup(ll);
				if(!ll) yyerror("place instance does not exist");
				a = new arc_list;
				a -> place = PS;
				a -> mt = (UTermList *) 0;
				a -> nu =mc -> mult;
				a -> next = root;
				root = a;
			}
		}
	}
  }
  /* Anzahl der Boegen */
  for(card = 0, current = root;current;card++,current = current -> next);
  T->LeavingArcs = new  Arc * [card+10];
  /* Schleife ueber alle Boegen */
  for(current = root;current;current = current -> next)
    {
	  /* Bogen ist nur HL-Bogen */
	  if(current -> place -> sort) continue;
      /* gibt es Bogen schon? */

      for(i = 0; i < T->NrOfLeaving;i++)
	{
	  if(current->place -> place == T->LeavingArcs[i]->pl)
	    {
	      /* Bogen existiert, nur Vielfachheit addieren */
	      *(T->LeavingArcs[i]) += current->nu;
	      break;
	    }
	}
      if(i>=T->NrOfLeaving)
	{
	  T->LeavingArcs[T->NrOfLeaving] = new Arc(T,current->place -> place,false,current->nu);
	  T -> NrOfLeaving++;
	  current -> place -> place -> references ++;
	}
    }
	// B) switch to next assignment
nextass:
	if((!LocalTable) || LocalTable -> card == 0) break;
	unsigned int k;
	VaSymbol * vv;
	for(k=0;k < LocalTable -> size;k++)
	{
		for(vv = (VaSymbol *) (LocalTable-> table[k]); vv;vv = (VaSymbol *) (vv -> next))
		{
			(*(vv -> var -> value)) ++;
			if(!(vv -> var -> value -> isfirst()) ) break;
		}
		if(vv) break;
	}
	if(!vv) break;
	}
}
    break;

  case 152:

/* Line 1455 of yacc.c  */
#line 1748 "readnet-syntax.yy"
    {(yyval.value) = 0;}
    break;

  case 153:

/* Line 1455 of yacc.c  */
#line 1749 "readnet-syntax.yy"
    {(yyval.value) = 1;}
    break;

  case 154:

/* Line 1455 of yacc.c  */
#line 1750 "readnet-syntax.yy"
    {(yyval.value) = 2;}
    break;

  case 155:

/* Line 1455 of yacc.c  */
#line 1752 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(256);}
    break;

  case 156:

/* Line 1455 of yacc.c  */
#line 1753 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(256);}
    break;

  case 157:

/* Line 1455 of yacc.c  */
#line 1755 "readnet-syntax.yy"
    { (yyval.ex) = (UExpression *) 0;}
    break;

  case 158:

/* Line 1455 of yacc.c  */
#line 1756 "readnet-syntax.yy"
    {if((yyvsp[(2) - (2)].ex) -> type -> tag != boo) yyerror("guard expression must be boolean"); (yyval.ex) = (yyvsp[(2) - (2)].ex);}
    break;

  case 159:

/* Line 1455 of yacc.c  */
#line 1758 "readnet-syntax.yy"
    { (yyval.al) = (arc_list *) 0;}
    break;

  case 160:

/* Line 1455 of yacc.c  */
#line 1759 "readnet-syntax.yy"
    {(yyval.al) = (yyvsp[(1) - (1)].al);}
    break;

  case 161:

/* Line 1455 of yacc.c  */
#line 1760 "readnet-syntax.yy"
    {
      (yyvsp[(1) - (3)].al)-> next = (yyvsp[(3) - (3)].al);
	  (yyval.al) = (yyvsp[(1) - (3)].al);
    }
    break;

  case 162:

/* Line 1455 of yacc.c  */
#line 1765 "readnet-syntax.yy"
    {
      unsigned int i;
      PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
      if(!PS)
	{
	  yyerror("place does not exist");
	}
	if(PS -> sort)
	{
		yyerror("arc expression of high level places must be term expressions");
	}
      (yyval.al) = new arc_list;
      (yyval.al) -> place = PS;
      (yyval.al)-> next = (arc_list *)  0;
      sscanf((yyvsp[(3) - (3)].str),"%u",&i);
      (yyval.al) -> nu = i;
	  (yyval.al) -> mt = (UTermList *) 0;
    }
    break;

  case 163:

/* Line 1455 of yacc.c  */
#line 1783 "readnet-syntax.yy"
    {
		UTermList * tl;
		PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
		if(!PS)
		{
			yyerror("place does not exist");
		}
		if(!(PS -> sort))
		{
			yyerror("low level places require numerical multiplicity");
		}
		(yyval.al) = new arc_list;
		(yyval.al) -> place = PS; 
		(yyval.al) -> nu = 0;
		(yyval.al) -> mt = (yyvsp[(3) - (3)].tlist);
		(yyval.al) -> next = (arc_list *) 0;
		for(tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl -> next)
		{
			if(!(PS -> sort -> iscompatible(tl -> t -> type)))
			{
				yyerror("type mismatch between place and arc expression");
			}
		}
	}
    break;

  case 164:

/* Line 1455 of yacc.c  */
#line 1808 "readnet-syntax.yy"
    { 
			(yyval.ex) = new UIntconstantExpression();
			sscanf((yyvsp[(1) - (1)].str),"%u",&(((UIntconstantExpression *) (yyval.ex)) -> nu));
			}
    break;

  case 165:

/* Line 1455 of yacc.c  */
#line 1813 "readnet-syntax.yy"
    {
			if((yyvsp[(2) - (3)].ex) -> type -> tag != num)
			{
				yyerror("integer expression expected");
			}
			(yyval.ex) = (yyvsp[(2) - (3)].ex);
			}
    break;

  case 166:

/* Line 1455 of yacc.c  */
#line 1821 "readnet-syntax.yy"
    {
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = eq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
				    }
    break;

  case 167:

/* Line 1455 of yacc.c  */
#line 1826 "readnet-syntax.yy"
    {
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = neq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
				  }
    break;

  case 168:

/* Line 1455 of yacc.c  */
#line 1831 "readnet-syntax.yy"
    {
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = leq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
				  }
    break;

  case 169:

/* Line 1455 of yacc.c  */
#line 1836 "readnet-syntax.yy"
    {
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type= geq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
				    }
    break;

  case 170:

/* Line 1455 of yacc.c  */
#line 1841 "readnet-syntax.yy"
    {
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = lt;
					(yyval.form) = (yyvsp[(1) - (3)].form);
				    }
    break;

  case 171:

/* Line 1455 of yacc.c  */
#line 1846 "readnet-syntax.yy"
    {
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = gt;
					(yyval.form) = (yyvsp[(1) - (3)].form);
	                            }
    break;

  case 172:

/* Line 1455 of yacc.c  */
#line 1851 "readnet-syntax.yy"
    {
					   (yyval.form) = new binarybooleanformula(conj,(yyvsp[(1) - (3)].form),(yyvsp[(3) - (3)].form));
                                           }
    break;

  case 173:

/* Line 1455 of yacc.c  */
#line 1854 "readnet-syntax.yy"
    {
			                   (yyval.form) = new binarybooleanformula(disj,(yyvsp[(1) - (3)].form),(yyvsp[(3) - (3)].form));
                                          }
    break;

  case 174:

/* Line 1455 of yacc.c  */
#line 1857 "readnet-syntax.yy"
    {
                                        (yyval.form) = new unarybooleanformula(neg,(yyvsp[(2) - (2)].form));
                                 }
    break;

  case 175:

/* Line 1455 of yacc.c  */
#line 1860 "readnet-syntax.yy"
    {
				if((yyvsp[(2) - (3)].ex) -> type -> tag != boo)
				{	
					yyerror("formula requires boolean expression");
				}
				(yyval.form) = new staticformula((yyvsp[(2) - (3)].ex));
					   }
    break;

  case 176:

/* Line 1455 of yacc.c  */
#line 1867 "readnet-syntax.yy"
    {
		(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
		(yyval.form) = new quantifiedformula(qe,(yyvsp[(2) - (4)].varsy)->var,(yyvsp[(4) - (4)].form));
		}
    break;

  case 177:

/* Line 1455 of yacc.c  */
#line 1871 "readnet-syntax.yy"
    {
		(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
		(yyval.form) = new quantifiedformula(qa,(yyvsp[(2) - (4)].varsy)->var,(yyvsp[(4) - (4)].form));
		}
    break;

  case 178:

/* Line 1455 of yacc.c  */
#line 1875 "readnet-syntax.yy"
    {
                                     (yyval.form) = (yyvsp[(2) - (3)].form);
                                    }
    break;

  case 179:

/* Line 1455 of yacc.c  */
#line 1878 "readnet-syntax.yy"
    {
                                  (yyval.form) = new untilformula(eu,(yyvsp[(4) - (7)].form),(yyvsp[(6) - (7)].form),(transitionformula *) (yyvsp[(2) - (7)].form));
                                                              }
    break;

  case 180:

/* Line 1455 of yacc.c  */
#line 1881 "readnet-syntax.yy"
    {
                             (yyval.form) = new untilformula(au,(yyvsp[(4) - (7)].form),(yyvsp[(6) - (7)].form),(transitionformula *) (yyvsp[(2) - (7)].form));
                                                              }
    break;

  case 181:

/* Line 1455 of yacc.c  */
#line 1884 "readnet-syntax.yy"
    {
                           (yyval.form) = new unarytemporalformula(eg,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
                                           }
    break;

  case 182:

/* Line 1455 of yacc.c  */
#line 1887 "readnet-syntax.yy"
    {
                                (yyval.form) = new unarytemporalformula(ag,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
                                           }
    break;

  case 183:

/* Line 1455 of yacc.c  */
#line 1890 "readnet-syntax.yy"
    {
                                      (yyval.form) = new unarytemporalformula(ex,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
                                         }
    break;

  case 184:

/* Line 1455 of yacc.c  */
#line 1893 "readnet-syntax.yy"
    {
				(yyval.form) = new unarytemporalformula(ax,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
                                        }
    break;

  case 185:

/* Line 1455 of yacc.c  */
#line 1896 "readnet-syntax.yy"
    {
                                      (yyval.form) = new unarytemporalformula(ef,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
                                         }
    break;

  case 186:

/* Line 1455 of yacc.c  */
#line 1899 "readnet-syntax.yy"
    {
				(yyval.form) = new unarytemporalformula(af,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
                                        }
    break;

  case 187:

/* Line 1455 of yacc.c  */
#line 1903 "readnet-syntax.yy"
    {
				    PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (1)].str));
                    if(!PS) yyerror("Place does not exist");
					if(PS -> sort) yyerror("HL places require instance");
					(yyval.form) = new hlatomicformula(neq,PS,(UExpression *) 0);
				  }
    break;

  case 188:

/* Line 1455 of yacc.c  */
#line 1909 "readnet-syntax.yy"
    {
				    PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (5)].str));
                    if(!PS) yyerror("Place does not exist");
                    if(!(PS-> sort)) yyerror("LL places do not require instance");
					if(!(PS -> sort ->iscompatible((yyvsp[(4) - (5)].ex) -> type)))
					{
						yyerror("place color incompatible to place sort");
					}
					(yyval.form) = new hlatomicformula(neq,PS,(yyvsp[(4) - (5)].ex));
				}
    break;

  case 189:

/* Line 1455 of yacc.c  */
#line 1920 "readnet-syntax.yy"
    {
		UVar * vv;
		VS = (VaSymbol *) LocalTable -> lookup((yyvsp[(1) - (3)].str));
		if(VS) yyerror("variable used twice in formula");
		vv = new UVar((yyvsp[(3) - (3)].t));
		(yyval.varsy) = new VaSymbol((yyvsp[(1) - (3)].str),vv);
	}
    break;

  case 190:

/* Line 1455 of yacc.c  */
#line 1928 "readnet-syntax.yy"
    { (yyval.form) = (transitionformula *) 0;}
    break;

  case 191:

/* Line 1455 of yacc.c  */
#line 1929 "readnet-syntax.yy"
    { (yyval.form) = (yyvsp[(1) - (1)].form);}
    break;

  case 192:

/* Line 1455 of yacc.c  */
#line 1931 "readnet-syntax.yy"
    {
					(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
					(yyval.form) = new quantifiedformula(qe,(yyvsp[(2) - (4)].varsy) -> var,(yyvsp[(4) - (4)].form));
					}
    break;

  case 193:

/* Line 1455 of yacc.c  */
#line 1935 "readnet-syntax.yy"
    {
					(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
					(yyval.form) = new quantifiedformula(qa,(yyvsp[(2) - (4)].varsy) -> var,(yyvsp[(4) - (4)].form));
					}
    break;

  case 194:

/* Line 1455 of yacc.c  */
#line 1939 "readnet-syntax.yy"
    {
						(yyval.form) = new binarybooleanformula(conj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
					}
    break;

  case 195:

/* Line 1455 of yacc.c  */
#line 1942 "readnet-syntax.yy"
    {
						(yyval.form) = new binarybooleanformula(disj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
					}
    break;

  case 196:

/* Line 1455 of yacc.c  */
#line 1945 "readnet-syntax.yy"
    {
						(yyval.form) = new unarybooleanformula(neg,(yyvsp[(2) - (2)].form));
					}
    break;

  case 197:

/* Line 1455 of yacc.c  */
#line 1948 "readnet-syntax.yy"
    {(yyval.form) = (yyvsp[(2) - (3)].form);}
    break;

  case 198:

/* Line 1455 of yacc.c  */
#line 1949 "readnet-syntax.yy"
    {
					if((yyvsp[(1) - (1)].ts)->vars && (yyvsp[(1) - (1)].ts) -> vars -> card)
					{
						yyerror("HL transition requires firing mode");
					}
					(yyval.form) = new transitionformula((yyvsp[(1) - (1)].ts) -> transition);
				}
    break;

  case 199:

/* Line 1455 of yacc.c  */
#line 1956 "readnet-syntax.yy"
    {
					if((! (yyvsp[(1) - (5)].ts) -> vars) || ((yyvsp[(1) - (5)].ts) -> vars -> card == 0))
					{
						yyerror("LL transition does not require firing mode");
					}
					(yyval.form) = new transitionformula((yyvsp[(1) - (5)].ts),(yyvsp[(4) - (5)].fm));
				}
    break;

  case 200:

/* Line 1455 of yacc.c  */
#line 1964 "readnet-syntax.yy"
    {
					TS = (TrSymbol *) TransitionTable -> lookup((yyvsp[(1) - (1)].str));
					if(!TS) yyerror("transition does not exist");
					(yyval.ts) = TS;
				}
    break;

  case 201:

/* Line 1455 of yacc.c  */
#line 1970 "readnet-syntax.yy"
    { (yyval.fm) = (yyvsp[(1) - (1)].fm);}
    break;

  case 202:

/* Line 1455 of yacc.c  */
#line 1971 "readnet-syntax.yy"
    {
					(yyvsp[(1) - (3)].fm) -> next = (yyvsp[(3) - (3)].fm);
					(yyval.fm) = (yyvsp[(1) - (3)].fm);
				}
    break;

  case 203:

/* Line 1455 of yacc.c  */
#line 1976 "readnet-syntax.yy"
    {
			VS = (VaSymbol *) (TS -> vars -> lookup((yyvsp[(1) - (3)].str)));
			if(!VS) yyerror("no such transition variable");
			if(! (VS -> var -> type -> iscompatible((yyvsp[(3) - (3)].ex) -> type)))
			{
				yyerror("variable binding incompatible with variable type");
			}
			(yyval.fm) = new fmode;
			(yyval.fm) -> v = VS;
			(yyval.fm) -> t = (yyvsp[(3) - (3)].ex) ;
			(yyval.fm) -> next = (fmode *) 0;
		}
    break;

  case 204:

/* Line 1455 of yacc.c  */
#line 1989 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
	BuchiTable = new SymbolTab(10);}
    break;

  case 205:

/* Line 1455 of yacc.c  */
#line 1991 "readnet-syntax.yy"
    {
				{
						int i,j;
						buchitransition * bt;
						for(i=0;i<buchistate::nr;i++)
						{
							buchistate * b = buchiautomaton[i];
							b -> delta = new buchitransition * [b -> nrdelta+1];
							for(j=0,bt = b -> transitionlist;bt;bt = bt -> next,j++)
							{
								b -> delta[j] = bt;
							}
						}
					    }
						// process all guard formulas
						int i, j, res;
						for(i=0;i<Places[0]->NrSignificant;i++)
						{
							Places[i]-> cardprop = 0;
							Places[i]-> propositions = (formula **) 0;
						}
						for(i=0;i<buchistate::nr;i++)
						for(j=0;j<buchiautomaton[i]->nrdelta;j++)
						{
							buchiautomaton[i]->delta[j]->guard =
							buchiautomaton[i]->delta[j]->guard -> replacequantifiers();
							buchiautomaton[i]->delta[j]->guard -> tempcard = 0;
							buchiautomaton[i]->delta[j]->guard =
							buchiautomaton[i]->delta[j]->guard -> merge();
							buchiautomaton[i]->delta[j]->guard =
							buchiautomaton[i]->delta[j]->guard -> reduce(&res);
							if(res == 0) buchiautomaton[i]->delta[j] = (buchitransition *) 0;
							buchiautomaton[i]->delta[j]->guard =
							buchiautomaton[i]->delta[j]->guard -> posate();
							buchiautomaton[i]->delta[j]->guard -> tempcard = 0;
						}
						for(i=0;i<buchistate::nr;i++)
						for(j=0;j<buchiautomaton[i]->nrdelta;j++)
						{
							buchiautomaton[i]->delta[j]->guard -> setstatic();
							if(buchiautomaton[i]->delta[j]->guard -> tempcard)
							{
								yyerror("temporal operators not allowed in buchi automaton");
							}
						}
						
#endif						
		}
    break;

  case 206:

/* Line 1455 of yacc.c  */
#line 2040 "readnet-syntax.yy"
    {
			// unused: int i;
			buchistate * b;
			buchiautomaton = new buchistate * [buchistate::nr];
			for(b=initialbuchistate;b;b=b->next)
			{
				buchiautomaton[b->code] = b;
			}
				 }
    break;

  case 207:

/* Line 1455 of yacc.c  */
#line 2050 "readnet-syntax.yy"
    { StSymbol * s ; 
					if( (s = (StSymbol *) (BuchiTable -> lookup((yyvsp[(3) - (3)].str)))) )
					{
						yyerror("State name in Buchi automaton used twice");
					}
					s = new StSymbol((yyvsp[(3) - (3)].str));
					if(!initialbuchistate)
					{
						initialbuchistate = s -> state;
					}
					else
					{
						s -> state -> next = initialbuchistate -> next;
						initialbuchistate -> next = s -> state;
					}  
				  }
    break;

  case 208:

/* Line 1455 of yacc.c  */
#line 2066 "readnet-syntax.yy"
    { StSymbol * s;
					if( (s = (StSymbol *) (BuchiTable -> lookup((yyvsp[(1) - (1)].str)))) )
					{
						yyerror("State name in Buchi automaton used twice");
					}
					s = new StSymbol((yyvsp[(1) - (1)].str));
					if(!initialbuchistate)
					{
						initialbuchistate = s -> state;
					}
					else
					{
						s -> state -> next = initialbuchistate -> next;
						initialbuchistate -> next = s -> state;
					}  
				  }
    break;

  case 210:

/* Line 1455 of yacc.c  */
#line 2085 "readnet-syntax.yy"
    { StSymbol * s;
					s = (StSymbol *) BuchiTable -> lookup((yyvsp[(3) - (3)].str));
					if(!s) yyerror("state does not exist");
					s -> state -> final = 1;
				 }
    break;

  case 211:

/* Line 1455 of yacc.c  */
#line 2090 "readnet-syntax.yy"
    { StSymbol * s;
					s = (StSymbol *) BuchiTable -> lookup((yyvsp[(1) - (1)].str));
					if(!s) yyerror("state does not exist");
					s -> state -> final = 1;
	 }
    break;

  case 214:

/* Line 1455 of yacc.c  */
#line 2099 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(2); }
    break;

  case 215:

/* Line 1455 of yacc.c  */
#line 2099 "readnet-syntax.yy"
    {
			StSymbol * from, * to;
			buchitransition * bt;
			from = (StSymbol *) BuchiTable -> lookup((yyvsp[(2) - (7)].str));
			if(!from) yyerror("state does not exist");
			to = (StSymbol *) BuchiTable -> lookup((yyvsp[(4) - (7)].str));
			if(!to) yyerror("state does not exist");
			bt = new buchitransition;
			bt -> next = from -> state -> transitionlist;
			from -> state -> transitionlist = bt;
			(from -> state -> nrdelta )++;
			bt -> delta = to -> state;
			bt -> guard = (yyvsp[(7) - (7)].form);
		}
    break;



/* Line 1455 of yacc.c  */
#line 4784 "readnet-syntax.cc"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1675 of yacc.c  */
#line 2114 "readnet-syntax.yy"



char * diagnosefilename;


void readnet()
{
	yydebug = 0;
	diagnosefilename = (char *) 0;
	if(netfile)
	{
		yyin = fopen(netfile,"r");
		if(!yyin)
		{
      fprintf(stderr, "lola: cannot open netfile '%s'\n", netfile);
			exit(4);
		}
		diagnosefilename = netfile;
	}
	GlobalTable = new SymbolTab(1024);
	TheBooType = new UBooType();
	TheNumType = new UNumType(0,INT_MAX);
	yyparse();
	unsigned int ii;
	for(ii=0;ii < Places[0]->cnt;ii++)
	{
	 	CurrentMarking[ii] = Places[ii]->initial_marking;
		Places[ii]->index = ii;
	}
if(F) 
{
	  F = F -> replacequantifiers();
	  F -> tempcard = 0;
	  F = F -> merge();
#if defined(MODELCHECKING) 
	unsigned int i;
	for(i=0;i< Transitions[0]->cnt;i++)
	{
		Transitions[i] -> lstfired = new unsigned int [F -> tempcard];
		Transitions[i] -> lstdisabled = new unsigned int [F -> tempcard];
	}
#endif
}
}

/*
bool taskfile = false;

int yywrap()
{
	yylineno = 1;
	if(taskfile) return 1;
	if(!analysefile) return 1;
	taskfile = true;
	yyin = fopen(analysefile,"r");
	if(!yyin)
	{
		cerr << "cannot open analysis task file: " << analysefile << "\n";
		exit(4);
	}
	diagnosefilename = analysefile;
	return(0);
}
*/


/// display a parser error and exit
void yyerror(char const * mess) {
    fprintf(stderr, "lola: %s:%d: error near '%s': %s\n", diagnosefilename, yylineno, yytext, mess);
	exit(3);
}


